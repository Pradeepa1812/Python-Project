from django.urls import path, include, re_path
from rest_framework.routers import DefaultRouter

from compare import views

urlpatterns = [
    path(r'api/compare-kpi-chart',views.compare_kpi_charts),
    path(r'api/compare-split-customers',views.split_by_customer),
    path(r'api/compare-split-brand-ppg' , views.split_by_retailer_brand_ppg),
    path(r'api/compare-promo-chart',views.promo_compare),
    path(r'api/comapare-visibility-chart',views.visibilty_compare),
    path(r'api/comapare-discount-chart',views.discount_compare),
    path(r'api/compare-incremental-baseline' ,views.incremental_baseline)
]