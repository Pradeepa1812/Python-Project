import pandas as pd
import os
import numpy as np

def incremental_splits(df,incremental_cols,baseline_col,incremental_col,event_start,event_end):
    
    # increm_cols = [col for col in df.columns if 'Impact' in col]
    # incremental_cols = [col for col in increm_cols if col not in ('Base Price Impact', 'Assumed_Display_Impact',"TDP Impact")]
    
    baseline = baseline_col
    incrementals = incremental_col
    
    df["total_sales"] = df[baseline_col]+df[incremental_col]
    totals  = "total_sales"
    
    
    df_copy = df.copy()
    
    df_copy["impact_products"] = df_copy.loc[:,incremental_cols].prod(axis = 1)
    
    
    for i in incremental_cols:
        col_name = str(i)+"_temp"
        df_copy[col_name] = df_copy[totals]/df_copy[i]
    
    
    
    for i in incremental_cols:
        df_copy[i+"_diff"] = df_copy[totals] - df_copy[i+"_temp"]
    
    
    for i in incremental_cols:
        df_copy[i+"_diff"] = df_copy[totals] - df_copy[i+"_temp"]
        
    
    for i in incremental_cols:
        diff_col = [col for col in df_copy.columns if '_diff' in col]
        
        df_copy[i+"_diff_perc"] = df_copy[i+"_diff"].div(df_copy[diff_col].sum(axis=1), axis=0)
        
    
    
    for i in incremental_cols:
        df_copy[i+"_split"] = df_copy[i+"_diff_perc"]*df_copy[incrementals]
    
    df_copy["year"] = pd.to_datetime(df_copy["event_ends_in_store"]).dt.year
    
    split_col = [col for col in df_copy.columns if '_split' in col]
    
    col_to_sel = ["retailer",'ppg',event_start,event_end,"year",baseline,incrementals,totals]
                   # 'Visibility Impact_split', 'BiScenarioPlanner.objects.all().values()g.Bet Impact_split', 'Discount Impact_split', 
                   # 'Push Impact_split', 'Mailer Impact_split', 'Newspaper Impact_split', 'SM Impact_split']
   
    
    col_to_sel.extend(split_col)
    
   
    
    return df_copy[col_to_sel]
    

def incremental_split_month(df,df_conso,ppg,ret,year,event_start,event_end,baseline_col,incremental_col):
    
    df_dates = pd.DataFrame()
    df_dates["date"] = pd.date_range(start = pd.to_datetime(year+"-01-01"),end = pd.to_datetime(year+"-12-31"))
    df_f = df_dates.merge(df,how = "cross")
   
    df1 = df_f[(df_f["date"] >= df_f[event_start]) &
                        (df_f["date"] <= df_f[event_end])]
    
    df1["no_of_days"] = (pd.to_datetime(df1[event_end])-pd.to_datetime(df1[event_start])).dt.days
    df1["no_of_days"] = df1["no_of_days"]+1
    
    col_to_split= [col for col in df1.columns if col not in ("date","year","ppg","retailer","lookup",
                                                             event_end,event_start,"no_of_days")]
    
    for i in col_to_split:
        df1[i] = df1[i].div(df1["no_of_days"],axis = 0)
    
    split_col = [col for col in df1.columns if '_split' in col]
    
    print(split_col)
    df1['total_sales'] = df1[baseline_col]+ df1[incremental_col]
    
    groupby_cols = [baseline_col,incremental_col,'total_sales']
    groupby_cols.extend(split_col)
    
    df_final = df1.groupby(["date"],as_index = False)[groupby_cols].sum()
    
    
    
    df_final = pd.merge(df_dates, df_final,on ="date",how = "left")
    
    ab = df_final.groupby([df_final.date.dt.month])[baseline_col].transform('mean')
    df_final["features.baseline"] = df_final[baseline_col].fillna(ab)
    df_final["month"] = df_final["date"].dt.strftime("%b")
   
    groupby_cols1 = ["features.baseline",incremental_col,'total_sales']
    groupby_cols1.extend(split_col)
    df_final = df_final.groupby(["month"],as_index = False)[groupby_cols1].sum()
    
 
    df_final["ppg"] = ppg
    df_final["retailer"] = ret
    df_final["year"] = int(year)
    
    return df_final    
    
def incre_splits_monthly(df,df_conso):
   dfs = pd.DataFrame()
   df["lookup"] = df["year"].astype(str)+","+ df["retailer"]+","+ df["ppg"] 

   for i in df['lookup'].unique():
        df1 = df[df['lookup'] == i]
    
       
        ppg  = i.split(",")[2]
        ret  = i.split(",")[1]
        year = i.split(",")[0]

 
        monthly_data = incremental_split_month(df1,df_conso,ppg,ret,year,"event_starts_in_store","event_ends_in_store",'features.baseline', 'features.incremental_units')
        dfs = pd.concat([monthly_data,dfs])
       
   # dfs = dfs.drop(["baseline","incremental","total_sales"],axis = 1)
   
   #print(df_conso.columns)
   #print("@@@@@@@@@@@@@@@@")
   #print(dfs.columns)
   df_res = pd.merge(df_conso,dfs,on = ["ppg","retailer","month"],how = "left")
   
   df_res["predicted_baseline"] = np.where((df_res['features.baseline'] == 0) | (df_res['features.baseline'].isna()),
                                      df_res["baseline_old"],df_res["features.baseline"])
   
   df_res["predicted_incremental"] = np.where((df_res['features.incremental_units'] == 0) | (df_res['features.incremental_units']).isna(),
                                      df_res["incrementals_old"],df_res["features.incremental_units"])
   
   df_res["predicted_total"] = df_res["predicted_baseline"] + df_res["predicted_incremental"] 

   return df_res
    

