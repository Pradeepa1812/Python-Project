from django.shortcuts import render
from compare import custom_methods
from rest_framework.decorators import api_view

@api_view(['GET'])
def compare_kpi_charts(request):
    results = custom_methods.get_kpi_values(request)
    return results


@api_view(['GET'])
def split_by_customer(request):
    split_by_customer_values = custom_methods.get_split_by_cutomer(request)
    return split_by_customer_values


@api_view(['GET'])
def split_by_retailer_brand_ppg(request):
    split_by_values = custom_methods.get_split_by_brands_ppg(request)
    return split_by_values


@api_view(['GET'])
def promo_compare(request):
    promo_results = custom_methods.get_promo_compare_values(request)
    return promo_results


@api_view(['GET'])
def visibilty_compare(request):
    visibilty_results = custom_methods.get_visibility_comapre_values(request)
    return visibilty_results


@api_view(['GET'])
def discount_compare(request):
    discount_results = custom_methods.get_discount_compare_values(request)
    return discount_results


@api_view(['GET'])
def incremental_baseline(request):
    incremental_baseline_result = custom_methods.get_incremental_baseline_values(request)
    return incremental_baseline_result