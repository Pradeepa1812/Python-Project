import pandas as pd
import os
import numpy as np
from scenario.models import ScenarioPlanner,HistoricalSummary,Baselines
from rest_framework.response import Response
from scenario import custom_methods as scenario_methods
from django.db.models import Max,Sum,FloatField,Count,Avg,F,DurationField
from django.core.exceptions import ObjectDoesNotExist
from rest_framework import status
from django.db.models.functions import Cast
from common.models import CompareBaseYear
from compare import impact_chart_algo
from datetime import datetime


def get_scenario_filtered_qs(request):
    
    scenario_filter_list = scenario_methods.build_scenario_filter(request)

    scenario_list = ScenarioPlanner.objects.filter(**scenario_filter_list)

    return scenario_list


def get_historical_qs(scenario_list):
    
    historical_filter_qs = HistoricalSummary.objects.filter(retailer__in=scenario_list.values_list('retailer' , flat=True).distinct(), brand__in = scenario_list.values_list('brand', flat=True).distinct() ,category__in = scenario_list.values_list('category' , flat=True).distinct() , ppg__in = scenario_list.values_list('ppg', flat=True ).distinct() , is_disable=0)

    historical_year = CompareBaseYear.objects.all()[0].year.year

    historical_filter_qs = historical_filter_qs.filter(event_ends_in_store__year = historical_year)

    return historical_filter_qs


def get_kpi_round_value(value_list):

    result = {}
    for key , value in value_list.items():
        if key in  ['roi', 'nr_uplift']:
            result[key]=round(value*100 , 2)
        else:
            result[key]=round(value , 2) if value != None else 0
    
    return result


def get_round_Off_value(value_list):
    return_val = []
    for values in value_list:
        result = {}
        for key,value in values.items():
            if key in ['retailer','brand','ppg']:
                result[key]=value
            elif key == 'events_counts':
                result[key]= round(value , 2) if value != None else 0
            elif key == 'event_total_spend':
                result_event_total = []
                for val in value:
                    individual_result = {}
                    for in_key,in_value in val.items():
                        if in_key == 'features__bucket':
                            individual_result[in_key] = in_value
                        else:
                            individual_result[in_key] = round(in_value , 2) if in_value != None else 0
                    result_event_total.append(individual_result) 
                result[key]=result_event_total
            else:
                result[key] = round(value*100, 2) if value != None else 0
        return_val.append(result)

    return return_val

def get_total_kpi_value(qs_value):
    results = qs_value.aggregate(incremental_units = Sum('features__incremental_units' , output_field=FloatField()),baseline = Sum('features__new_baseline' , output_field=FloatField()),event_total_spend=Sum('features__event_total_spend' , output_field=FloatField()), roi=Sum('features__inc_gp' , output_field=FloatField())/Sum('features__inc_gtn' , output_field=FloatField()) ,nr_uplift=Sum('features__inc_nr' , output_field=FloatField())/Sum('features__base_nr' , output_field=FloatField()))
    return results


def get_kpi_values(request):
    try:
        
        scenario_list = get_scenario_filtered_qs(request)

        scenario_kpi_total = get_total_kpi_value(scenario_list)

        historical_filter_qs = get_historical_qs(scenario_list)

        historical_kpi_total = get_total_kpi_value(historical_filter_qs)

        return Response(data={'current_year':get_kpi_round_value(scenario_kpi_total),'previous_year':get_kpi_round_value(historical_kpi_total)})

    except ObjectDoesNotExist:
        
        return Response(data='No data found' , status=status.HTTP_404_NOT_FOUND)


def get_customer_values(qs_set):
    results = qs_set.aggregate(roi=Sum('features__inc_gp' , output_field=FloatField())/Sum('features__inc_gtn' , output_field=FloatField()) ,nr_uplift=Sum('features__inc_nr' , output_field=FloatField())/Sum('features__base_nr' , output_field=FloatField()),event_count=Count('retailer'),event_total_spend=Sum('features__event_total_spend', output_field=FloatField()))
    
    results['event_total_spend'] = qs_set.values('features__bucket').distinct().annotate(event_total_spend=Sum('features__event_total_spend', output_field=FloatField())/results['event_total_spend']*100)
    
    return results


def get_split_by_cutomer(request):
    try:
        scenario_list = get_scenario_filtered_qs(request)

        historical_filter_qs = get_historical_qs(scenario_list)

        return Response(data={'current_year':get_customer_values(scenario_list),'previous_year':get_customer_values(historical_filter_qs)})

    except ObjectDoesNotExist:
        
        return Response(data='No data found' , status=status.HTTP_404_NOT_FOUND)


def get_split_by_list(event_list , group_by_value):
    
    results = event_list.values(group_by_value).annotate(events_counts=Cast(Count(group_by_value)/event_list.count()*100, FloatField()) ,roi=Sum('features__inc_gp' , output_field=FloatField())/Sum('features__inc_gtn' , output_field=FloatField()) ,nr_uplift=Sum('features__inc_nr' , output_field=FloatField())/Sum('features__base_nr' , output_field=FloatField()))
    
    final_result = []
    
    for result in results:

        if group_by_value == 'brand':
            total_spend = event_list.filter(brand=result[group_by_value]).aggregate(total=Sum('features__event_total_spend', output_field=FloatField()))
            result['event_total_spend']=event_list.filter(brand=result[group_by_value]).values('features__bucket').distinct().annotate(event_total_spend=Sum('features__event_total_spend', output_field=FloatField())/total_spend['total']*100)
        elif group_by_value == 'ppg':
            total_spend = event_list.filter(ppg=result[group_by_value]).aggregate(total=Sum('features__event_total_spend', output_field=FloatField()))
            result['event_total_spend']=event_list.filter(ppg=result[group_by_value]).values('features__bucket').distinct().annotate(event_total_spend=Sum('features__event_total_spend', output_field=FloatField())/total_spend['total']*100)
        else:
            total_spend = event_list.filter(retailer=result[group_by_value]).aggregate(total=Sum('features__event_total_spend', output_field=FloatField()))
            result['event_total_spend']=event_list.filter(retailer=result[group_by_value]).values('features__bucket').distinct().annotate(event_total_spend=Sum('features__event_total_spend', output_field=FloatField())/total_spend['total']*100)
        
        final_result.append(result)
    
    return final_result


def get_split_by_brands_ppg(request):
    try:
        split_by_name = request.GET.get('group_by')

        scenario_list = get_scenario_filtered_qs(request)

        historical_filter_qs = get_historical_qs(scenario_list)

        scenario_split_by_value = get_split_by_list(scenario_list , split_by_name)

        hitorical_split_by_value = get_split_by_list(historical_filter_qs , split_by_name)

        result_list = {'current_year':get_round_Off_value(scenario_split_by_value),'previous_year':get_round_Off_value(hitorical_split_by_value)}

        return Response(data=result_list)

    except ObjectDoesNotExist:
        
        return Response(data='No data found' , status=status.HTTP_404_NOT_FOUND)




def get_promo_round(value_list):
    
    result = {}
    for key ,value in value_list.items():
        if key == 'avg_days' and value != None:
            result[key]=value.days
        elif value == None:
            result[key]=0
        elif key == 'avg_days':
            result[key]=value.days
        elif key in ['roi','nr_uplift']:
            result[key]=round(value*100, 2)
        elif key == 'avg_total_spend':
            result[key]=round(value/1000,2)
        else:
            result[key]=round(value, 2)
    
    return result



def get_yes_no_value(filter_value_yes , event_qs):
    result = {}
    
    result['yes_value'] = get_promo_round(event_qs.filter(**filter_value_yes).aggregate(event=Count('retailer'),avg_total_spend=Avg('features__event_total_spend' , output_field=FloatField()), avg_days=Avg(F('event_ends_in_store')-F('event_starts_in_store') ,output_field=DurationField()),roi=Sum('features__inc_gp' , output_field=FloatField())/Sum('features__inc_gtn' , output_field=FloatField()) ,nr_uplift=Sum('features__inc_nr' , output_field=FloatField())/Sum('features__base_nr' , output_field=FloatField())))
    result['no_value'] = get_promo_round(event_qs.exclude(**filter_value_yes).aggregate(event=Count('retailer'),avg_total_spend=Avg('features__event_total_spend' , output_field=FloatField()), avg_days=Avg(F('event_ends_in_store')-F('event_starts_in_store'), output_field=DurationField()),roi=Sum('features__inc_gp' , output_field=FloatField())/Sum('features__inc_gtn' , output_field=FloatField()) ,nr_uplift=Sum('features__inc_nr' , output_field=FloatField())/Sum('features__base_nr' , output_field=FloatField()))) 
    return result


def get_promo_compare(query_set):
    final_result = {}

    final_result['display'] = get_yes_no_value({'features__visibility__in':['2x2','4x4','2x4','GE','Power Wall','Home Shelf']},query_set)
    final_result['mailer'] = get_yes_no_value({'features__mailer':'Yes'},query_set)
    final_result['newspaper'] = get_yes_no_value({'features__newspaper':'Yes'},query_set)
    final_result['social_media'] = get_yes_no_value({'features__social_media':'Yes'},query_set)
    final_result['ge_tag'] = get_yes_no_value({'features__visibility':'GE'},query_set)
    final_result['4x4_tag'] = get_yes_no_value({'features__visibility':'4x4'},query_set)
    final_result['power_wall_tag'] = get_yes_no_value({'features__visibility':'Power Wall'},query_set)

    return final_result


def get_promo_compare_values(request):
    try:

        scenario_list = get_scenario_filtered_qs(request)

        historical_filter_qs = get_historical_qs(scenario_list)

        sceanrio_promo_compare = get_promo_compare(scenario_list)

        historical_promo_compare = get_promo_compare(historical_filter_qs)

        final_result = {'current_year':sceanrio_promo_compare,'previous_year':historical_promo_compare}

        return Response(data=final_result)

    except ObjectDoesNotExist:
        
        return Response(data='No data found' , status=status.HTTP_404_NOT_FOUND)




def get_visibility_compare_results(event_qs):
    results = {}
    
    for value in ['2x2','2x4','4x4','GE' ,'Power Wall','Home Shelf']:
        
        results[value]=event_qs.filter(features__visibility=value).aggregate(total_days_between=Sum(F('event_ends_in_store')-F('event_starts_in_store')))
        
        if results[value]['total_days_between'] == None:
            results[value]['total_days_between']=0
        else:
            results[value]['total_days_between']=results[value]['total_days_between'].days
    
    return results




def get_visibility_comapre_values(request):
    try:
        scenario_list = get_scenario_filtered_qs(request)

        historical_filter_qs = get_historical_qs(scenario_list)

        base_year = CompareBaseYear.objects.all()[0].year.year

        final_result={'current_year':get_visibility_compare_results(scenario_list),'previous_year':get_visibility_compare_results(historical_filter_qs),'base_year':base_year}

        return Response(data=final_result)

    except ObjectDoesNotExist:
        
        return Response(data='No data found' , status=status.HTTP_404_NOT_FOUND)



def get_range_name(value):
    range_name = ''
    
    if value == 0:
        range_name = '0_5'
    elif value == 0.06:
        range_name = '5_10'
    elif value == 0.11:
        range_name = '10_15'
    elif value == 0.16:
        range_name = '15_20'
    elif value == 0.21:
        range_name = '20_25'
    elif value == 0.26:
        range_name = '25_above'
    
    return range_name



def get_discount_compare_results(query_set):
    results = {}
    for val_start,val_end in [[0,0.06],[0.06,0.11],[0.11 , 0.16],[0.16,0.21],[0.21,0.26],[0.26,1]]:
        range_name = get_range_name(val_start)
        results[range_name] = query_set.filter(features__discount__range=(val_start , val_end)).aggregate(total_days_between=Sum(F('event_ends_in_store')-F('event_starts_in_store')))
       
        if results[range_name]['total_days_between'] == None:
       
            results[range_name]['total_days_between']=0
       
        else:
            results[range_name]['total_days_between']=results[range_name]['total_days_between'].days
    
    return results



def get_discount_compare_values(request):
    try:
        
        scenario_list = get_scenario_filtered_qs(request)

        historical_filter_qs = get_historical_qs(scenario_list)

        base_year = CompareBaseYear.objects.all()[0].year.year

        final_result={'current_year':get_discount_compare_results(scenario_list),'previous_year':get_discount_compare_results(historical_filter_qs) , 'base_year':base_year}

        return Response(data=final_result)

    except ObjectDoesNotExist:
        
        return Response(data='No data found' , status=status.HTTP_404_NOT_FOUND)
    



def get_algo_filtered_result(scenario_list , algo_results):
    final_set = pd.DataFrame()
    
    filter_set = scenario_list.values('retailer' , 'category','brand' , 'ppg' , 'event_ends_in_store__month' , 'event_ends_in_store__year').distinct()
    
    for events in filter_set:
        result = algo_results[(algo_results['retailer']== events['retailer']) & (algo_results['category'].str.contains(events['category']))& (algo_results['brand']==events['brand'])&(algo_results['ppg']==events['ppg']) & (algo_results['month']==datetime(2000, events['event_ends_in_store__month'], 1).strftime('%b')) & (algo_results['year'] == float(datetime(events['event_ends_in_store__year'], 1, 1).strftime('%Y')))]
        final_set = final_set.append(result , ignore_index=True)

    data={}
    for col_name in final_set.columns:
        if 'features' in col_name:
            data[col_name.replace('features.' , "").replace('_impact_split' ,"").lower()]=round(final_set[col_name].sum(),2)
    
    data['total']=round(final_set['predicted_total'].sum(),2)
    return data


def get_incremental_baseline_values(request):

        scenario_list = get_scenario_filtered_qs(request)

        df_contri = pd.DataFrame(pd.json_normalize(scenario_list.values()))

        df_conso = pd.DataFrame(Baselines.objects.all().values())

        incremental_col = ['features.discount_impact' ,'features.bigbet_impact' , 'features.mailer_impact' , 'features.newspaper_impact' , 'features.visibility_impact' , 'features.push_promoter_impact','features.social_media_impact']

        df_split = impact_chart_algo.incremental_splits(df_contri,incremental_col,"features.baseline","features.incremental_units","event_starts_in_store","event_ends_in_store")

        df_res = impact_chart_algo.incre_splits_monthly(df_split,df_conso)

        final_result = get_algo_filtered_result(scenario_list , df_res)

        return Response(data=final_result)