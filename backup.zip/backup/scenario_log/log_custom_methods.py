import pandas as pd

from scenario_log.models import ScenarioLog
from scenario.models import ScenarioPlanner
from scenario_log.serializers import ScenarioLogSerializers

def old_new_difference(validated_data,scenario_name):


            old_value =['old_cogs','old_tdp','old_on_invoice_terms','old_off_invoice_terms','old_distributor_terms','old_list_price','old_grammage']
            new_value =['cogs','tdp','on_invoice_terms','off_invoice_terms','distributor_terms','list_price','grammage']
            event = value['features']
            event_logs={}
            event_log_lists = []

            for i in range(0,len(old_value)):
                if event[old_value[i]] != event[new_value[i]]:
                    ScenarioPlanner.objects.all().filter(scenario_id=scenario_name.id).values_list('id',
                                                                                                   'features__old_cogs',
                                                                                                   'features__old_tdp',
                                                                                                   'features__old_on_invoice_terms',
                                                                                                   'features__old_off_invoice_terms',
                    event_logs.update({'field': old_value[i], 'old_value': event[old_value[i]], 'new_value': event[new_value[i]],'event' :event_id[i]['id'] ,'scenario':scenario_name.id,})
                event_log_lists.append(event_logs)

            print(event_log_lists)

            ScenarioLog.objects.bulk_create(event_log_lists)

            log_events_data = ScenarioLogSerializers(data=event_log_lists)

            print('(((',log_events_data)

            if log_events_data.is_valid():
                value = log_events_data.save()
            return "data stored"



