from django.db import models
from scenario_log.models import ScenarioLog
from rest_framework import serializers

class ScenarioLogSerializers(serializers.ModelSerializer):
    class Meta:
        model = ScenarioLog
        fields = ('__all__')
