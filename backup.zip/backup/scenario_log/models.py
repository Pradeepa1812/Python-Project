from django.db import models

# Create your models here.

class ScenarioLog(models.Model):
    event = models.ForeignKey('scenario.ScenarioPlanner', on_delete=models.CASCADE)
    scenario = models.ForeignKey('scenario.ScenarioSummary', on_delete=models.CASCADE)
    field = models.CharField(max_length=100)
    old_value = models.CharField(max_length=50)
    new_value = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "tpas_event_logs"