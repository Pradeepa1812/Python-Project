# This Module is used for custom methods implementations
import numpy as np
import pandas as pd
from rest_framework import status
from dateutil import parser
from rest_framework.response import Response
from scenario.models import ModelCoeff,DebaseBaseline,DefaultValues,ScenarioSummary,ScenarioPlanner,HistoricalSummary,Baselines
from scenario import impact
from rest_framework.settings import api_settings
from rest_framework_csv.renderers import CSVRenderer
from common.models import Metadata,Target
from dateutil.parser import parse
import pickle
import json
from datetime import datetime
from django.db.models import FloatField,Sum,Count,F
from django.db.models.functions import Concat
from django.db.models.functions import ExtractMonth,ExtractYear
from scenario.serializers import ScenarioEventsSerializers,UploadScenarioEventsSerializers
from django.core.exceptions import ObjectDoesNotExist
import logging
logger = logging.getLogger('django')

def df_to_formatted_json(df, sep="."):

    result = []
    for idx, row in df.iterrows():
        parsed_row = {}

        for col_label, v in row.items():
            keys = col_label.split(".")
            current = parsed_row

            for i, k in enumerate(keys):
                if i == len(keys) - 1:
                    current[k] = v
                else:
                    if k not in current.keys():
                        current[k] = {}
                    current = current[k]

        result.append(parsed_row)
    return result


def promo_impact(promo_df, promo_name):
    coeff_df = pd.DataFrame(list(ModelCoeff.objects.all().values()))

    promo_impact_value = None

    if promo_name == "mailer":
        promo_impact_value = impact.mailer_impact(promo_df, coeff_df)
    elif promo_name == "newspaper":
        promo_impact_value = impact.newspaper_impact(promo_df, coeff_df)
    elif promo_name == "big_bet":
        promo_impact_value = impact.bigbet_impact(promo_df, coeff_df)
    elif promo_name == "social_media":
        promo_impact_value = impact.sm_impact(promo_df, coeff_df)
    elif promo_name == "push_promoter":
        promo_impact_value = impact.pushpromoter_impact(promo_df, coeff_df)
    elif promo_name == "discount":
        promo_impact_value = impact.discount_impact(promo_df, coeff_df)
    elif promo_name == "visibility":
        promo_impact_value = impact.visibility_impact(promo_df, coeff_df)
    
    return promo_impact_value


def data_cleaning(df):
    df = [x.lower() for x in df.columns]
    df = [df.rstrip() for df in df]
    df = [col.replace("-", "_") for col in df]
    df = [col.replace(" ", "_") for col in df]
    return df


def df_to_formatted_json_data(df, sep="."):

    result = []
    for idx, row in df.iterrows():
        parsed_row = {}

        for col_label, v in row.items():
            keys = col_label.split(".")
            current = parsed_row

            for i, k in enumerate(keys):
                if i == len(keys) - 1:
                    current[k] = v
                else:
                    if k not in current.keys():
                        current[k] = {}
                    current = current[k]
        parsed_row.update({"market": 1})
        result.append(parsed_row)
    return result


def headerBuild(table_name):

    headers_value = {}
    column_headers_values_ = (
        Metadata.objects.all().order_by("ui_ordering").filter(table_name__in=table_name).exclude(table_column_name="id"))

    for header in column_headers_values_:
        headers_value[header.table_column_name] = header.ui_name

    return headers_value




def is_date(string, fuzzy=False):
    try: 
        parse(string, fuzzy=fuzzy)
        return True

    except ValueError:
        return False

def is_number(number):
    try: 
        int(number)
        return True

    except ValueError:
        return False



def event_name_vallidation(validated_data):
    scenario_name = str(validated_data["scenario_name"]).split("_")
    event = validated_data["scenario_events"]
    reatiler_name = event[0]["retailer"]
    if len(scenario_name)==3:
        if scenario_name[0] == reatiler_name and is_date(scenario_name[1]) and len(scenario_name[1].split("-"))==3 and is_number(scenario_name[2]):
            return True
        else:
            return False
    else:
        return False

def date_vallidation(validated_data):
        for event in validated_data['scenario_events']:
            if parser.parse(str(event["event_starts_in_store"])) >= parser.parse(str(event["event_ends_in_store"])):
                print(event['event_starts_in_store'], event['event_ends_in_store'])
                return True
        return False

def dates_format_change(df_final):
    def date_format_change(df):
        logger.info('Changing date format...')
        df = pd.to_datetime(df,dayfirst=True)
        df = df.dt.strftime("%Y-%m-%d")
        return df

    df_final['event_starts_in_store'] = date_format_change(df_final['event_starts_in_store'])
    df_final['event_ends_in_store'] = date_format_change(df_final['event_ends_in_store'])
    return df_final

def dates_format_change_algo(df_final):
        logger.info('Changing date format...')
        def date_format_change_algo(df):
            df = pd.to_datetime(df)
            df = df.dt.strftime("%d-%b-%Y")
            return df

        df_final['event_starts_in_store'] = date_format_change_algo(df_final['event_starts_in_store'])
        df_final['event_ends_in_store'] = date_format_change_algo(df_final['event_ends_in_store'])
        return df_final




def get_default_values(df_input):
    default_value = DefaultValues.objects.all()
    base_price = []
    tdp = []
    cogs = []
    list_price = []
    off_invoice = []
    on_invoice = []
    distributor_terms = []
    grammage = []

    for index, row in df_input.iterrows():
        key = str(row["ppg"])+"_"+str(row["retailer"])+"_"+"Malaysia" 
        for values in default_value:
            if values.key == key:
                if values.feature == 'Base Price':
                    base_price.append(values.default_value)
                elif values.feature == 'TDP':
                    tdp.append(values.default_value)
                elif values.feature == 'List Price':
                    list_price.append(values.default_value)
                elif values.feature == 'COGS':
                    cogs.append(values.default_value)
                elif values.feature == 'Off_Invoice':
                    off_invoice.append(values.default_value)
                elif values.feature == 'On_Invoice':
                    on_invoice.append(values.default_value)
                elif values.feature == 'Distributor_Terms':
                    distributor_terms.append(values.default_value)
                elif values.feature == 'Grammage':
                    grammage.append(values.default_value)

        if len(base_price)!= index+1 :
            base_price.extend([0])
            tdp.extend([0])
            cogs.extend([0])
            list_price.extend([0])
            off_invoice.extend([0])
            on_invoice.extend([0])
            distributor_terms.extend([0])
            grammage.extend([0])

    df_input["features.old_base_price"] = base_price
    df_input["features.old_tdp"] = tdp
    df_input["features.old_list_price"] = list_price
    df_input["features.old_cogs"] = cogs
    df_input["features.old_off_invoice_terms"] = off_invoice
    df_input["features.old_on_invoice_terms"] = on_invoice
    df_input["features.old_distributor_terms"] = distributor_terms
    df_input["features.old_grammage"] = grammage

    return df_input


def value_modification(df_input , col_name , defalut_col_name):
    return_val = []

    for index, row in df_input.iterrows():
        if (row[col_name] == "") or pd.isnull(row[col_name]) or row[col_name] == 0 or row[col_name] == 0.0:
            return_val.append(row[defalut_col_name])
        else:
            return_val.append(row[col_name])

    return return_val


def get_modified_value(df_input):
    df_input["features.base_price"] = value_modification(df_input, "features.base_price" ,"features.old_base_price")
    df_input["features.tdp"] = value_modification(df_input, "features.tdp" ,"features.old_tdp")
    df_input["features.list_price"] = value_modification(df_input, "features.list_price" ,"features.old_list_price")
    df_input["features.cogs"] = value_modification(df_input, "features.cogs" ,"features.old_cogs")
    df_input["features.off_invoice_terms"] = value_modification(df_input, "features.off_invoice_terms" ,"features.old_off_invoice_terms")
    df_input["features.on_invoice_terms"] = value_modification(df_input, "features.on_invoice_terms" ,"features.old_on_invoice_terms")
    df_input["features.distributor_terms"] = value_modification(df_input, "features.distributor_terms" ,"features.old_distributor_terms")
    df_input["features.grammage"] = value_modification(df_input, "features.grammage" ,"features.old_grammage")
    return df_input


def validation_modification(df_input):
    df_input = get_default_values(df_input)
    df_input = get_modified_value(df_input)
    df_input = dates_format_change_algo(df_input)
    return df_input

def default(df_input):

    return df_input

def upload_name_validations(validated_data,scenario_name):
    scenario_name = str(scenario_name).split("_")
    reatiler_name = validated_data[0]['retailer']
    if len(scenario_name) == 3:
        if scenario_name[0] == reatiler_name and is_date(scenario_name[1]) and len(scenario_name[1].split("-")) == 3 and is_number(scenario_name[2]):
            pass
        else:
            return False
    else:
        return False

def multiple_retailer(df_input):
    retailer_list = []
    for value in df_input.to_dict('records'):
        retailer_list.append({'retailer': value['retailer']})

    unique_retailer_validators = list(map(pickle.loads, set(map(pickle.dumps, retailer_list))))
    if len(unique_retailer_validators) > 1:
        return "Yes"


def upload_unique_together_validations(df_input):

    retailers = multiple_retailer(df_input)
    if retailers == "Yes":
        return retailers

    df = df_input[(df_input['ppg']=='CDM MORE SPECIAL (LP)') | (df_input['ppg'] == 'THE SPECIAL SHAREBAG (LP)')]
    df= df.loc[df.duplicated(subset=['ppg', 'brand', 'event_starts_in_store', 'event_ends_in_store'],keep='first'),:]
    df_input = df_input.drop(df.index.values)
    df_input = df_input.reset_index()
    store_validators = []
    keys = ['ppg', 'brand', 'event_starts_in_store', 'event_ends_in_store']

    for value in df_input.to_dict('records'):
        store_validators.append({keys[0]: value[keys[0]], keys[1]: value[keys[1]], keys[2]: value[keys[2]], keys[3]: value[keys[3]]})

    unique_validators = list(map(pickle.loads, set(map(pickle.dumps, store_validators))))
    if len(store_validators) != len(unique_validators):
        return True
    return df_input


def upload_validations(df_input,scenario_name):
    validated_data = df_input.to_dict('records')
    name_validation = upload_name_validations(validated_data, scenario_name)
    if name_validation == False:
        return name_validation

    for date in validated_data:
        if parse(date['event_starts_in_store']) >= parse(date['event_ends_in_store']):
            return "date_val"

    validators = upload_unique_together_validations(df_input)

    if (type(validators) == str and validators == "Yes") or (type(validators) == bool and validators == True):
        return validators
    else:
        return validators


def promo_mechanics_null_replacing(df_input):
    promo_mech = ['big_bet', 'newspaper', 'mailer', 'social_media','push_promoter']
    for value in promo_mech:
        df_input['features.'+value]= df_input['features.'+value].fillna('No')
    return df_input

def scenario_file_upload(scenario_file ,scneario_name):
    replace_header = {}
    df_input = pd.read_csv(scenario_file)
    df_input.dropna(axis='rows',how = 'all', inplace=True)
    coeff_df = pd.DataFrame(list(ModelCoeff.objects.all().values()))
    baseline_df = pd.DataFrame(list(DebaseBaseline.objects.all().values()))
    header = Metadata.objects.filter(table_name = "historical").values("table_column_name" , "ui_name")
    for value in header:
         replace_header[value['ui_name']]=value['table_column_name']

    try:
        df_input.rename(columns=replace_header , inplace=True)
        logger.info('Column Name renamed....')
        mand_values = df_input[['retailer','ppg','brand','category','event_starts_in_store','event_ends_in_store']]
        null_value_check = mand_values.isna().values.any()

        if null_value_check == True:
            return Response(data={'Please Fill the Mandotary Field Values'}, status=status.HTTP_404_NOT_FOUND)

        validators = upload_validations(df_input,scneario_name)
        if type(validators) == bool and validators == False:
            return Response(data={"Invalid Name Format"}, status=status.HTTP_404_NOT_FOUND)
        if type(validators) == bool and validators == True:
            return Response(data={"PPG,Brand,StartDate,EndDate Unique Together in Upload CSV"},status=status.HTTP_404_NOT_FOUND)
        if type(validators) == str and validators =="Yes":
            return Response(data={"Multiple Retailers Not Allowed"},status=status.HTTP_404_NOT_FOUND)
        if type(validators) == str and validators == "date_val":
            return Response(data={"End Date Should be greater than start date"}, status=status.HTTP_404_NOT_FOUND)
        df_input = validators
        df_input = validation_modification(df_input)
        df_input = promo_mechanics_null_replacing(df_input)
        df_input.fillna(0, inplace=True)
        df_input[['features.modelled_competition_1', 'features.modelled_competition_2', 'features.visibility']] = df_input[['features.modelled_competition_1', 'features.modelled_competition_2', 'features.visibility']].replace(0, "")
        df_final = impact.event_calculation(df_input,coeff_df,baseline_df ,False)

    except KeyError as e:
        return Response(data={'Please Upload Correct Data File...'}, status=status.HTTP_404_NOT_FOUND)

    df_final.replace([np.inf, -np.inf], np.nan, inplace=True)
    df_final.fillna(0, inplace=True)
    df_final[['features.modelled_competition_1', 'features.modelled_competition_2', 'features.visibility']] = df_final[['features.modelled_competition_1', 'features.modelled_competition_2', 'features.visibility']].replace(0, "")
    df_final = dates_format_change_algo(df_final)
    data = df_to_formatted_json_data(df_final)
    data= {'scenario_name':scneario_name,"scenario_events":data}
    events_data = UploadScenarioEventsSerializers(data=data)
    if events_data.is_valid():

        value,status_code = events_data.save()
        if isinstance(value ,str):
            return Response(data=value, status=status_code)

        else:
            return Response(data=str(value.scenario_name)+" Scenario Created Successfully" ,status=status_code)

    return Response(data=events_data.errors, status=status.HTTP_404_NOT_FOUND)



def unique_together_validators(validated_data):
    store_validators = []
    keys = ['ppg','brand', 'event_starts_in_store', 'event_ends_in_store']
    retailer_list=[]

    for i in range(1, len(validated_data.items())):

        for value in validated_data['scenario_events']:

                retailer_list.append({'retailer':value['retailer']})

                store_validators.append({keys[0]: value[keys[0]],keys[1]:value[keys[1]],keys[2]:value[keys[2]],keys[3]:value[keys[3]]})

    unique_retailer_validators = list(map(pickle.loads, set(map(pickle.dumps, retailer_list))))

    if len(unique_retailer_validators) > 1:
        return "Yes"

    unique_validators = list(map(pickle.loads, set(map(pickle.dumps, store_validators))))

    if len(store_validators) != len(unique_validators):
        return True

    return False


def build_scenario_filter(request):
    filters = {}

    for key , value in request.GET.items():
        if key in ['page' , 'page_size' , 'group_by' , 'filter']:
            pass
        elif key == 'scenario__scenario_name' and value != '':
            event = ScenarioSummary.objects.get(scenario_name=value)
            filters['scenario_id'] = event.id
        elif key == 'event_ends_in_store__year':
            if value != None and value != '':
                filters[key]=value
        else:
            if value != None and value != '':
                filters[str(key)+"__in"]=to_array(value)

    return filters

def get_filter(request):
    filters = build_scenario_filter(request)
    baselines = pd.DataFrame(list(Baselines.objects.all().values()))
    filtered_events = pd.DataFrame(ScenarioPlanner.objects.filter(**filters).values('retailer','ppg','brand' , 'category' ,'event_ends_in_store' ,'event_starts_in_store' , 'features__baseline' ,'features__incremental_units'))
    if len(filtered_events)== 0:
        return Response(data='No Data Found' , status=status.HTTP_404_NOT_FOUND)
    
    calculated_value = impact.get_view_summary_baseline_incremental(filtered_events,baselines,"event_starts_in_store","event_ends_in_store","features__baseline","features__incremental_units")

    return calculated_value

def to_array(ip):
    if ip != '':
        return ip.split(",")
    else:
        return ''


def get_target_filter(request):
    logger.info('Entered....')
    filters = {
        "scenario__scenario_name": request.query_params.get('scenario__scenario_name', ''),
        "event_ends_in_store__year": request.query_params.get('year', ''),
        "retailer__in": to_array(request.query_params.get('retailer', '')),
        "ppg__in": to_array(request.query_params.get('ppg', '')),
        "brand__in": to_array(request.query_params.get('brand', '')),
    }

    filters = {k: v for k, v in filters.items() if v}


    q= ScenarioPlanner.objects.filter(**filters)\
    .values('scenario__scenario_name','retailer', 'ppg')

    if len(q) > 0:
        qs = list(q.annotate(retailer_count = Count('retailer'), 
                                    ppg_count = Count('ppg'),
                                    incremental_units = Sum('features__incremental_units' , output_field=FloatField()), 
                                    baseline = Sum('features__baseline' , output_field=FloatField()),
                                    actual_units_sold=Sum('features__incremental_units' , output_field=FloatField()) + Sum('features__baseline' , output_field=FloatField()))\
                        .values('scenario__scenario_name','retailer','ppg','incremental_units','baseline','actual_units_sold'))

        for grouped_event in qs:
            target = Target.objects.filter(retailer=grouped_event['retailer'], ppg=grouped_event['ppg']).values('input_target_units')
            if(len(target) > 0):
                ip_target = target[0]
            else:
                ip_target = 1200
            grouped_event['actual_units_sold'] = round(grouped_event['actual_units_sold'])
            grouped_event['input_target_unit'] = round(ip_target)
            grouped_event['target_completion'] = round((grouped_event['actual_units_sold'] / grouped_event['input_target_unit']) * 100)

        return qs
    else:
        return []


def promo_impacts(ppg , retailer , promo_name , promo_values):
    promo_value = {}
    promo_value["ppg"]=ppg
    promo_value["retailer"]=retailer
    promo_value["features."+promo_name]=promo_values
    promo_df = pd.DataFrame(promo_value,index=[0])
    logger.info('Retrieving Promo impacts...')

    return promo_impact(promo_df, promo_name)


def get_actual_impact(ppg , retailer):
    result = {}
    result['mailer_actual_impact'] = promo_impacts(ppg ,retailer , 'mailer' , 'Yes')[0]
    result['newspaper_actual_impact'] = promo_impacts(ppg ,retailer , 'newspaper' , 'Yes')[0]
    result['push_promoter_actual_impact'] = promo_impacts(ppg ,retailer , 'push_promoter' , 'Yes')[0]
    result['social_media_actual_impact'] = promo_impacts(ppg ,retailer , 'social_media' , 'Yes')[0]
    result['big_bet_actual_impact'] = promo_impacts(ppg ,retailer , 'big_bet' , 'Yes')[0]
    visibity_list =['2x2' ,'4x4','2x4','GE' , 'Power Wall','Home Shelf']
    for visibility in visibity_list:

        result[str(visibility+"_actual_impact").lower().replace(" ", "_")]=promo_impacts(ppg ,retailer , 'visibility' , visibility)[0]

    return result


def get_filter_value(request):
    filter_name = request.GET.get('filter')
    try:
        filters = build_scenario_filter(request)
        filter_qs = ScenarioPlanner.objects.filter(**filters)
        filter_list = filter_qs.values_list(filter_name ,flat=True).distinct()
        if filter_list != None:
        
            return Response(data=filter_list , status=status.HTTP_200_OK)
        
        return Response(data='No data found' , status=status.HTTP_404_NOT_FOUND)

    except ObjectDoesNotExist:
        return Response(data='No data found' , status=status.HTTP_404_NOT_FOUND)


def build_historical_filter(request):
    filters = {}

    for key , value in request.GET.items():
        if key == 'filter':
            pass
        elif value != None and value != '':
            filters[key]=value
    
    return filters


def get_historical_filter_list(request):
    filter_name = request.GET.get('filter')
    filters = build_historical_filter(request)
    try :

        filters_list = HistoricalSummary.objects.filter(**filters).values_list(filter_name , flat=True).distinct()
        if len(filters_list) == 0:
            return Response(data='No data found' , status=status.HTTP_404_NOT_FOUND)
        return Response(data=filters_list , status=status.HTTP_200_OK)

    except ObjectDoesNotExist:
        return Response(data='No data found' , status=status.HTTP_404_NOT_FOUND)

def is_between(a, x, b):
    return min(a, b) < x < max(a, b)


def rename_reindex(data):
    header = Metadata.objects.all().order_by("ui_ordering").filter(table_name="log_report").values("table_column_name","ui_name",'ui_ordering')
    replace_header = {}
    for value in header:
        replace_header[value['table_column_name']] = value['ui_name']

    metadata_key = [key for key, value in replace_header.items()]
    metadata_value = [value for key, value in replace_header.items()]

    for dataframe_col in list(data.columns.values):
        if dataframe_col not in metadata_key:
            data.drop(dataframe_col, axis=1, inplace=True)

    data = data.rename(columns=replace_header)
    data = data.reindex(columns=metadata_value)
    return data


def log_report_data(qs):
    data = pd.json_normalize(list(qs.values()))
    data.drop(['created_at', 'updated_at'], axis=1, inplace=True)
    data = rename_reindex(data)
    return data


