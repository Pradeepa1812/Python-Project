# -*- coding: utf-8 -*-
"""
Created on Mon Sep 20 18:02:18 2021

@author: bhupesh.kurdiya
"""
import pandas as pd
import numpy as np
from datetime import datetime
from scenario import custom_methods
import logging
logger = logging.getLogger('django')

# key = df_input["ppg"] + "_" + df_input["retailer"] + "_" + "Malaysia"


def discount_impact(df,model_coeff_df):
    
    return_val = []
    
    """
        Filter out the coefficient value(coeff_val) of discount corresponding to each ppg and retailer combination and 
        calculate discount impact as (1-discount)^coeff_val.
        
        Discount values : [0.3,0.5,0.7,...]
        Parameters
        ----------
        df : Input Dataframe
        
        model_coeff_df : Coefficient dataframe 

        Returns
        -------
        Discount Impacts as a list.
        ex: [1.2,1.3,1.6, ....]
    """
    
    
    for index, row in df.iterrows():
        if ((row["ppg"] == "") or (pd.isna(row["ppg"])) or (row["retailer"] == "") or (pd.isna(row["retailer"]))) :
                return_val.extend([1])
        else :
                key = row["ppg"]+"_"+row["retailer"]+"_"+"Malaysia"
                coeff_val = model_coeff_df[(model_coeff_df["key"] == key) & (model_coeff_df["feature"] == "Discount")]["default_value"]
                impact_val = (1-row["features.discount"])**coeff_val

                return_val.extend(impact_val)
    logger.info('** Calculating Discount impact')
    return return_val



def tdp_impact(df,model_coeff_df):
    
    """
        Filter out the coefficient value(coeff_val) of TDP corresponding to ppg and retailer combination and 
        calculate TDP impact as (TDP value)^coeff_val.

        TDP values : [300,120,80,...]
        Parameters
        ----------
        df : Input Dataframe
        
        model_coeff_df : Coefficient dataframe 

        Returns
        -------
        TDP Impacts as a list.
        ex: [10.3,100.2,50.6, ....]
    """

    return_val = []
    
    for index, row in df.iterrows():
        if ((row["ppg"] == "") or (pd.isna(row["ppg"])) or (row["retailer"] == "") or (pd.isna(row["retailer"]))) :
                return_val.extend([1])
        else :
                key = row["ppg"]+"_"+row["retailer"]+"_"+"Malaysia"
                coeff_val = model_coeff_df[(model_coeff_df["key"] == key) & (model_coeff_df["feature"] == "log_stores_selling")]["default_value"]
                impact_val = (row["features.tdp"])**coeff_val
                    
                return_val.extend(impact_val)
    logger.info('** Calculating tdp_impact ')
    return return_val

def comp_impact(df, model_coeff_df,comp_no):
    
    """
        Filter out the coefficient value(coeff_val) of Competitor corresponding to ppg and retailer combination and 
        calculate competitor impact as (1-competitor discount)^coeff_val.
        
        Competitor discount values : [0.3,0.5,0.7,...]
        Parameters
        ----------
        df : Input Dataframe
        
        model_coeff_df : Coefficient dataframe 

        Returns
        -------
        Competitor Impacts as a list.
        ex: [0.2,0.83,0.96, ....]
    """
    
    return_val = []
    comp_col = "features.modelled_competition_"  + str(comp_no)
    comp_discount_col = "features.competitor_discount_" + str(comp_no)

    for index, row in df.iterrows():
        if(pd.isnull(row[comp_discount_col]) or pd.isnull(row[comp_col]) or (row[comp_col] == "") or (row[comp_col] == "No Significant Competitor") or (pd.isna(row[comp_col])) or  (row["ppg"] == "") or (pd.isna(row["ppg"])) or (row["retailer"] == "") or (pd.isna(row["retailer"]))) :
                return_val.extend([1])
        else:
                key = row["ppg"]+"_"+row["retailer"]+"_"+"Malaysia"
                comp_name = row[comp_col]
                comp_name = comp_name.replace(' ','_')
                comp_name = comp_name.lower()
                comp_name = "comp_" + str(comp_name) +"_Discount"
                coeff_val = model_coeff_df[(model_coeff_df["key"] == key) & (model_coeff_df["feature"] == comp_name)]["default_value"]

                impact_val = (1- row[comp_discount_col])**coeff_val
                return_val.extend(impact_val)
    logger.info('** Calculating comp_impact')
    return return_val


def bigbet_impact(df, model_coeff_df):
    
    """
        Filter out the coefficient value(coeff_val) of Bigbet corresponding to each ppg and retailer combination and 
        calculate bigbet impact as exp(coeff_val).
        
        Bigbet values : ["Yes","Yes","No",...]
        Parameters
        ----------
        df : Input Dataframe
        
        model_coeff_df : Coefficient dataframe 

        Returns
        -------
        Bigbet Impacts as a list.
        ex:[2.2,1.4,1.6, ....]
    """
    
    
    return_val = []
    
    for index, row in df.iterrows():
        key = row["ppg"]+"_"+row["retailer"]+"_"+"Malaysia"
        if((row["features.big_bet"] == "No") or pd.isnull(row["features.big_bet"]) or (row["features.big_bet"] == "") or (pd.isna(row["features.big_bet"])) or 
            (row["ppg"] == "") or (pd.isna(row["ppg"])) or (row["retailer"] == "") or (pd.isna(row["retailer"]))) :
                return_val.extend([1])
        else:
            if(row["features.big_bet"] == "Yes"):
                coeff_val = model_coeff_df[(model_coeff_df["key"] == key) & (model_coeff_df["feature"] == "D_Ad_Support")]["default_value"]
                impact_val = np.exp(coeff_val)
                return_val.extend(impact_val)
    logger.info('** Calculating bigbet_impact')
    return return_val
    
def visibility_impact(df, model_coeff_df):
    
    """
        Filter out the coefficient value(coeff_val) of Visibility corresponding to each ppg and retailer combination(Row wise)
        and calculate visibility impact as exp(coeff_val).

        Visibility values : ["2x2","2x4","GE",...]
        Parameters
        ----------
        df : Input Dataframe
        
        model_coeff_df : Coefficient dataframe 

        Returns
        -------
        Visibility Impacts as a list.
        ex:[2.2,1.4,1.6, ....]
    """
    
    return_val = []
    
    for index, row in df.iterrows():
        key = row["ppg"]+"_"+row["retailer"]+"_"+"Malaysia"
        if((row["features.visibility"] == "No Visibility") or pd.isnull(row["features.visibility"]) or (row["features.visibility"] == "") or (row["features.visibility"] == 0) or 
            (row["ppg"] == "") or (pd.isna(row["ppg"])) or (row["retailer"] == "") or (pd.isna(row["retailer"]))) :
                return_val.extend([1])
        else:
            if(row["features.visibility"] == "2x2"):
                coeff_val = model_coeff_df[(model_coeff_df["key"] == key) & (model_coeff_df["feature"] == "D_2x2")]["default_value"]
                impact_val = np.exp(coeff_val)
                return_val.extend(impact_val)
            elif(row["features.visibility"] == "4x4"):
                coeff_val = model_coeff_df[(model_coeff_df["key"] == key) & (model_coeff_df["feature"] == "D_4x4")]["default_value"]
                impact_val = np.exp(coeff_val)
                return_val.extend(impact_val)
            elif(row["features.visibility"] == "2x4"):
                coeff_val = model_coeff_df[(model_coeff_df["key"] == key) & (model_coeff_df["feature"] == "D_2x4")]["default_value"]
                impact_val = np.exp(coeff_val)
                return_val.extend(impact_val)
            elif(row["features.visibility"] == "GE"):
                coeff_val = model_coeff_df[(model_coeff_df["key"] == key) & (model_coeff_df["feature"] == "D_GE")]["default_value"]
                impact_val = np.exp(coeff_val)
                return_val.extend(impact_val)
            elif(row["features.visibility"] == "Power Wall"):
                coeff_val = model_coeff_df[(model_coeff_df["key"] == key) & (model_coeff_df["feature"] == "D_Power_Wall")]["default_value"]
                impact_val = np.exp(coeff_val)
                return_val.extend(impact_val)
            elif(row["features.visibility"] == "Home Shelf"):
                coeff_val = model_coeff_df[(model_coeff_df["key"] == key) & (model_coeff_df["feature"] == "D_homeshelf")]["default_value"]
                impact_val = np.exp(coeff_val)
                return_val.extend(impact_val)
    logger.info('** Calculating visibility_impact')
    return return_val

def pushpromoter_impact(df, model_coeff_df):
    
    """
        Filter out the coefficient value(coeff_val) of Push Promoter corresponding to each ppg and retailer combination(Row wise)
        and calculate visibility impact as exp(coeff_val).
        
        Push promoter values : ["Yes","Yes","No",...]
        Parameters
        ----------
        df : Input Dataframe
        
        model_coeff_df : Coefficient dataframe 

        Returns
        -------
        Push promoter Impacts as a list.
        ex:[2.2,1.4,1.6, ....]
    """
    
    return_val = []
    
    for index, row in df.iterrows():
        key = row["ppg"]+"_"+row["retailer"]+"_"+"Malaysia"
        if((row["features.push_promoter"] == "No") or pd.isnull(row["features.push_promoter"]) or (row["features.push_promoter"] == "") or 
            (row["ppg"] == "") or (pd.isna(row["ppg"])) or (row["retailer"] == "") or (pd.isna(row["retailer"]))) :
                return_val.extend([1])
        else:
            if(row["features.push_promoter"] == "Yes"):
                coeff_val = model_coeff_df[(model_coeff_df["key"] == key) & (model_coeff_df["feature"] == "D_Promoter")]["default_value"]
                impact_val = np.exp(coeff_val)
                return_val.extend(impact_val)
    logger.info('** Calculating pushpromotor_impact ')
    return return_val

def mailer_impact(df, model_coeff_df):
    
    """
        Filter out the coefficient value(coeff_val) of Mailer corresponding to each ppg and retailer combination(Row wise)
        and calculate visibility impact as exp(coeff_val).
        
        Mailer values : ["Yes","Yes","No",...]
        Parameters
        ----------
        df : Input Dataframe
        
        model_coeff_df : Coefficient dataframe 

        Returns
        -------
        Mailer Impacts as a list.
        ex:[2.2,1.4,1.6, ....]
    """
    
    return_val = []
    
    for index, row in df.iterrows():
        key = row["ppg"]+"_"+row["retailer"]+"_"+"Malaysia"
        if((row["features.mailer"] == "No") or pd.isnull(row["features.mailer"]) or (row["features.mailer"] == "") or 
            (row["ppg"] == "") or (pd.isna(row["ppg"])) or (row["retailer"] == "") or (pd.isna(row["retailer"]))) :
                return_val.extend([1])
        else:
            if(row["features.mailer"] == "Yes"):
                coeff_val = model_coeff_df[(model_coeff_df["key"] == key) & (model_coeff_df["feature"] == "D_Mailer")]["default_value"]
                impact_val = np.exp(coeff_val)
                return_val.extend(impact_val)
    logger.info('** Calculating mailer_impact ')
    return return_val

def newspaper_impact(df, model_coeff_df):
    
    """
        Filter out the coefficient value(coeff_val) of Visibility corresponding to each ppg and retailer combination(Row wise)
        and calculate Newspaper impact as exp(coeff_val).
        
        Newspaper column values : ["Yes","Yes","No",...]
        Parameters
        ----------
        df : Input Dataframe
        
        model_coeff_df : Coefficient dataframe 

        Returns
        -------
        Newspaper Impacts as a list.
        ex:[2.2,1.4,1.6, ....]
    """
    
    return_val = []
    
    for index, row in df.iterrows():
        key = row["ppg"]+"_"+row["retailer"]+"_"+"Malaysia"
        if((row["features.newspaper"] == "No") or pd.isnull(row["features.newspaper"]) or (row["features.newspaper"] == "") or 
            (row["ppg"] == "") or (pd.isna(row["ppg"])) or (row["retailer"] == "") or (pd.isna(row["retailer"]))) :
                return_val.extend([1])
        else:
            if(row["features.newspaper"] == "Yes"):
                coeff_val = model_coeff_df[(model_coeff_df["key"] == key) & (model_coeff_df["feature"] == "D_Newspaper")]["default_value"]
                impact_val = np.exp(coeff_val)
                return_val.extend(impact_val)
    logger.info('** Calculating newspaper_impact')
    return return_val

def sm_impact(df, model_coeff_df):
    
    """
        Filter out the coefficient value(coeff_val) of Social Media corresponding to each ppg and retailer combination(Row wise)
        and calculate social media impact as exp(coeff_val).
        
        SM column values : ["Yes","Yes","No",...]
        Parameters
        ----------
        df : Input Dataframe
        
        model_coeff_df : Coefficient dataframe 

        Returns
        -------
        Social Media Impacts as a list.
        ex:[2.2,1.4,1.6, ....]
    """
    
    return_val = []
    
    for index, row in df.iterrows():
        key = row["ppg"]+"_"+row["retailer"]+"_"+"Malaysia"
        if((row["features.social_media"] == "No") or pd.isnull(row["features.social_media"]) or (row["features.social_media"] == "") or 
            (row["ppg"] == "") or (pd.isna(row["ppg"])) or (row["retailer"] == "") or (pd.isna(row["retailer"]))) :
                return_val.extend([1])
        else:
            if(row["features.social_media"] == "Yes"):
                coeff_val = model_coeff_df[(model_coeff_df["key"] == key) & (model_coeff_df["feature"] == "D_SM")]["default_value"]
                impact_val = np.exp(coeff_val)
                return_val.extend(impact_val)
    logger.info('** Calculating sm_impact ')
    return return_val

def baseline_calc(df,baseline_df):
    return_val = []
    
    """
        Calculate the baseline for each row
        
        Parameters
        ----------
        df : Input Dataframe
        
        baseline_df : dataframe with day wise baseline number.

        Returns
        -------
        Baseline as a list.
        ex:[100000,3543,7023, ....]
    """
    
    
    
    
    for index, row in df.iterrows():
        key = row["ppg"]+"_"+row["retailer"]+"_"+"Malaysia"
        if((row["event_starts_in_store"] == "") or (pd.isnull(row["event_starts_in_store"])) or
           (row["ppg"] == "") or (pd.isna(row["ppg"])) or (row["retailer"] == "") or (pd.isna(row["retailer"]))):
            return_val.extend([0])
        else:
            baseline_df['date'] = pd.to_datetime(baseline_df['date'])
            baseline_temp_df = baseline_df[baseline_df["key"] == key]
            start_date = pd.to_datetime(datetime.strptime(row["event_starts_in_store"],'%d-%b-%Y'))
            end_date = pd.to_datetime(datetime.strptime(row["event_ends_in_store"],'%d-%b-%Y'))
            mask = (baseline_temp_df['date'] >= start_date) & (baseline_temp_df['date'] <= end_date)
            
            baseline_temp_df = baseline_temp_df.loc[mask]
            baseline_sum = np.sum(baseline_temp_df["correct_debased_baseline"])
            return_val.extend([baseline_sum])
    logger.info('** Calculating baseline_calc')
    return return_val
    
def baseprice_impact(df , model_coeff_df):
    
    """
        Filter out the coefficient value(coeff_val) of Base Price corresponding to each ppg and retailer combination(Row wise)
        and calculate Base price impact as base price**coeff_val.
        
        Base price column values : [3,4,1,...]
        Base price % change column values : [0.23,0.43,0.01,...]
        Parameters
        ----------
        df : Input Dataframe
        
        model_coeff_df : Coefficient dataframe 

        Returns
        -------
        Visibility Impacts as a list.
        ex:[0.2,0.6,0.9, ....]
    """
    
    return_val = []

    for index, row in df.iterrows():
        key = row["ppg"]+"_"+row["retailer"]+"_"+"Malaysia" 
        if((row["features.base_price"] == "") or pd.isnull(row["features.base_price"]) or (row["features.base_price"] == "") or 
            (row["ppg"] == "") or (pd.isna(row["ppg"])) or (row["retailer"] == "") or (pd.isna(row["retailer"]))) :
                return_val.extend([1])
        else:
                bp = row["features.base_price"]
                bp_change = row["features.base_price_change"]
                bp = bp*(1+bp_change)
                coeff_val = model_coeff_df[(model_coeff_df["key"] == key) & (model_coeff_df["feature"] == "median_baseprice_log")]["default_value"]
                impact_val = bp**coeff_val
                return_val.extend(impact_val)
    logger.info('** Calculating baseprice_impact')
    return return_val
    


def incremental(df_input):
    logger.info('** Calculating incremental')
    return df_input["features.total_sales"] - df_input["features.new_baseline"]


def base_gsv(df_input):
    logger.info('** Calculating base_gsv ')
    return df_input["features.list_price"] * df_input["features.new_baseline"]


def event_tpr_spend(df_input):
    logger.info('** Calculating event_tpr_spend')
    return df_input["features.discount"]*df_input["features.list_price"]*df_input["features.total_sales"]


def event_variable_spend(df_input):
    print("event_visibility_spend")
    logger.info('** Calculating event_variable_spend ')
    return df_input["features.event_tpr_spend"] + df_input["features.event_visibility_spend"]


def base_nr(df_input):
    logger.info('** Calculating comp_impact ')
    return df_input["features.base_gsv"]-(df_input["features.base_gsv"]*(df_input["features.off_invoice_terms"]+df_input["features.on_invoice_terms"]-df_input["features.distributor_terms"]))


def base_nr_per_kg(df_input):
    logger.info('** Calculating base_nr_per_kg')

    return  df_input["features.base_nr"]/df_input["features.new_baseline"]


def cogs_gsv(df_input):
    logger.info('** Calculating cogs_gsv ')
    return df_input["features.cogs"]/df_input["features.list_price"]


def base_gp(df_input):
    logger.info('** Calculating base_gp')
    return df_input["features.base_nr"]-(df_input["features.cogs_gsv"]*df_input["features.base_gsv"])


def base_gp_base_nr(df_input):
    logger.info('** Calculating cogs_gsv ')
    return df_input["features.base_gp"]/df_input["features.base_nr"]


def event_gsv_sell_out(df_input):
    logger.info('** Calculating event_gsv_sell_out ')
    return  df_input["features.total_sales"]*df_input["features.list_price"]


def event_var_spend_gsv(df_input):
    logger.info('** Calculating event_var_spend_gsv ')
    return df_input["features.event_variable_spend"]/df_input["features.event_gsv_sell_out"]


def event_gtn(df_input):
    logger.info('** Calculating event_gtn ')
    return df_input["features.event_gsv_sell_out"]*(df_input["features.off_invoice_terms"]+df_input["features.on_invoice_terms"])+df_input["features.event_gsv_sell_out"]*df_input["features.distributor_terms"]+df_input["features.event_variable_spend"]


def event_nr(df_input):
    logger.info('** Calculating event_nr ')
    return df_input["features.event_gsv_sell_out"]-df_input["features.event_gtn"]


def event_cogs_consumer(df_input):
    logger.info('** Calculating event_cogs_consumer ')
    return df_input["features.event_gsv_sell_out"]*df_input["features.cogs_gsv"] 


def event_cogs_calc(df_input):
    logger.info('** Calculating event_cogs_calc')
    return df_input["features.event_cogs_to_consumer"]


def event_gp(df_input):
    logger.info('** Calculating event_gp ')
    return df_input["features.event_nr"]-df_input["features.event_cogs_for_calc"]


def event_gp_nr(df_input):
    logger.info('** Calculating event_gp')
    return df_input["features.event_gp"]/df_input["features.event_nr"]


def inc_unit(df_input):
    logger.info('** Calculating inc_unit')
    return df_input["features.total_sales"]-df_input["features.new_baseline"]


def inc_kg(df_input):
    logger.info('** Calculating inc_unit')
    return df_input["features.inc_unit"]*(df_input["features.grammage"]/1000)


def inc_gsv(df_input):
    logger.info('** Calculating inc_gsv')
    return df_input["features.event_gsv_sell_out"]-df_input["features.base_gsv"]


def inc_terms(df_input):
    logger.info('** Calculating inc_terms')
    return (df_input["features.off_invoice_terms"]+df_input["features.on_invoice_terms"])*(df_input["features.inc_unit"]*df_input["features.list_price"])


def inc_variable_spend(df_input):
    logger.info('** Calculating inc_variable_spend')
    return df_input["features.event_variable_spend"]


def inc_nr(df_input):
    logger.info('** Calculating inc_nr')
    return df_input["features.event_nr"]-df_input["features.base_nr"]


def inc_gp(df_input):
    logger.info('** Calculating inc_gp')
    return df_input["features.event_gp"]-df_input["features.base_gp"]


def nr_uplift(df_input):
    logger.info('** Calculating nr_uplift')
    return df_input["features.inc_nr"]/df_input["features.base_nr"]


def base_gtn(df_input):
    logger.info('** Calculating base_gtn')
    return df_input["features.base_gsv"] - df_input["features.base_nr"]


def event_gsv_sell_in(df_input):
    logger.info('** Calculating event_gsv_sell_in')
    return df_input["features.sell_in_units"]*df_input["features.list_price"]


def event_total_spend(df_input):
    logger.info('** Calculating event_total_spend')
    return df_input["features.event_gtn"]+df_input["features.addnl_consumer_spend"]


def event_total_spend_gsv(df_input):
    logger.info('** Calculating evant_total_spend_gsv')
    return df_input["features.event_total_spend"]/df_input["features.event_gsv_sell_out"]


def event_cogs_to_customer(df_input):
    logger.info('** Calculating event_cogs_to_customer')
    return df_input["features.event_gsv_sell_in"]*df_input["features.cogs_gsv"]


def inc_gtn(df_input):
    logger.info('** Calculating inc_gtn')
    return df_input["features.event_gtn"]-df_input["features.base_gtn"]


def inc_spend(df_input):
    logger.info('** Calculating inc_spend')
    return df_input["features.inc_gtn"]+df_input["features.addnl_consumer_spend"]


def cal_roi(df_input):
    logger.info('** Calculating cal_roi')
    return df_input["features.inc_gp"]/df_input["features.inc_gtn"]



def find_bucket(df_input):
    logger.info('** finding roi_bucket')

    return_val = []

    for index, row in df_input.iterrows():
        if  custom_methods.is_between(0,round(row['features.roi'],2),0.25):
            return_val.append('0-25 %')
        elif  custom_methods.is_between(0.26,round(row['features.roi'],2),0.50):
            return_val.append('25-50 %')
        elif custom_methods.is_between(0.51,round(row['features.roi'],2),1.00):
            return_val.append('50-100 %')
        elif custom_methods.is_between(1.01,round(row['features.roi'],2), 1.50):
            return_val.append('100-150 %')
        elif round(row['features.roi'],2) < 0 or row['features.roi']==None:
            return_val.append('negetive roi')
        else :
            return_val.append('over 150 %')

    return return_val



def impact_value_repalce(df_input , col_name  , rec_col_name ,promo_name):
    
    return_val = []

    for index, row in df_input.iterrows():
        if str(row[promo_name]).upper() ==  "NO" or row[promo_name] == "":
            return_val.append(row[col_name])
        elif (row[col_name] != 1):
           return_val.append(row[col_name])
        elif (row[rec_col_name] != ""):
           return_val.append(row[rec_col_name])
        else:
            return_val.append(row[col_name])

    return return_val



def get_old_actual_impact(df_input):

    df_input["features.actual_bigbet_impact"] = df_input["features.bigbet_impact"]

    df_input["features.actual_push_promoter_impact"] = df_input["features.push_promoter_impact"]

    df_input["features.actual_mailer_impact"] = df_input["features.mailer_impact"]

    df_input["features.actual_newspaper_impact"] = df_input["features.newspaper_impact"]

    df_input["features.actual_social_media_impact"] = df_input["features.social_media_impact"]

    df_input["features.actual_visibility_impact"] = df_input["features.visibility_impact"]

    return df_input




def promo_impact_modification(df_input):

    df_input["features.bigbet_impact"] = impact_value_repalce(df_input ,"features.bigbet_impact" , "features.recommended_bigbet_impact" ,"features.big_bet")
    
    df_input["features.push_promoter_impact"] = impact_value_repalce(df_input , "features.push_promoter_impact" , "features.recommended_push_promoter_impact" ,"features.push_promoter")

    df_input["features.mailer_impact"] = impact_value_repalce(df_input , "features.mailer_impact" , "features.recommended_mailer_impact" ,"features.mailer")
    
    df_input["features.newspaper_impact"] = impact_value_repalce(df_input , "features.newspaper_impact", "features.recommended_newspaper_impact" ,"features.newspaper" )
    
    df_input["features.social_media_impact"] = impact_value_repalce(df_input , "features.social_media_impact" , "features.recommended_social_media_impact" ,"features.social_media")

    df_input["features.visibility_impact"] = impact_value_repalce(df_input , "features.visibility_impact" , "features.recommended_visibility_impact" ,"features.visibility")

    return df_input

def decimal_conversion(df_input):
    decimal_conv = ['discount', 'on_invoice_terms', 'off_invoice_terms', 'distributor_terms', 'competitor_discount_1','competitor_discount_2','base_price_change']
    for values in decimal_conv:
        df_input['features.'+values] = df_input['features.'+values].apply(lambda x: x / 100)
    return df_input


def event_calculation(df_input,coeff_df,baseline_df , user_input):
    logger.info('Algorithm Event Calculation Started....')
    df_input = decimal_conversion(df_input)
    dis_im = discount_impact(df_input,coeff_df)
    tdp_im = tdp_impact(df_input,coeff_df)
    comp_im = comp_impact(df_input, coeff_df, 1)
    comp_im2 = comp_impact(df_input, coeff_df, 2)
    vis_im = visibility_impact(df_input, coeff_df)
    bb_im = bigbet_impact(df_input, coeff_df)
    pp_im = pushpromoter_impact(df_input, coeff_df)
    mail_im = mailer_impact(df_input, coeff_df)
    news_im= newspaper_impact(df_input, coeff_df)
    sm_im = sm_impact(df_input, coeff_df)
    baseline = baseline_calc(df_input, baseline_df)
    bp_im= baseprice_impact(df_input,coeff_df)
    
    df_input["features.discount_impact"] = dis_im
    
    df_input["features.tdp_impact"] = tdp_im
    
    df_input["features.competitor_1_impact"] = comp_im
    
    df_input["features.competitor_2_impact"] = comp_im2
    
    df_input["features.visibility_impact"] = vis_im
    
    df_input["features.bigbet_impact"] = bb_im
    
    df_input["features.push_promoter_impact"] = pp_im
    
    df_input["features.mailer_impact"] = mail_im
    
    df_input["features.newspaper_impact"] = news_im
    
    df_input["features.social_media_impact"] = sm_im

    df_input = get_old_actual_impact(df_input)
     
    #User can use the recommanded imapct to know the exact impact
    if user_input:
        df_input = promo_impact_modification(df_input)

    df_input["features.baseline"] = baseline
    
    df_input["features.base_price_impact"] = bp_im
    
    df_input["features.total_promo_impact"] = df_input["features.discount_impact"] * df_input["features.bigbet_impact"] * df_input["features.visibility_impact"] * df_input["features.push_promoter_impact"] * df_input["features.mailer_impact"] * df_input["features.newspaper_impact"] * df_input["features.social_media_impact"] * df_input["features.additional_assumed_impact"] 
    
    df_input["features.total_recommanded_impact"] = df_input["features.bigbet_impact"] * df_input["features.visibility_impact"] * df_input["features.push_promoter_impact"] * df_input["features.mailer_impact"] * df_input["features.newspaper_impact"] * df_input["features.social_media_impact"]

    df_input["features.total_non_promo_impact"] = df_input["features.tdp_impact"]*df_input["features.competitor_1_impact"]*df_input["features.competitor_2_impact"]*df_input["features.base_price_impact"]
    
    df_input["features.new_baseline"] = df_input["features.baseline"]*df_input["features.total_non_promo_impact"]*df_input["features.baseline_adjustment_factor"]
    
    df_input["features.total_sales"] = df_input["features.new_baseline"] * df_input["features.total_promo_impact"]
    
    df_input["features.incremental_units"] = incremental(df_input)
    
    df_input["features.base_gsv"] = base_gsv(df_input)

    df_input["features.event_tpr_spend"] = event_tpr_spend(df_input)

    df_input["features.event_variable_spend"] = event_variable_spend(df_input)

    df_input["features.base_nr"] = base_nr(df_input)

    df_input["features.base_nr_per_kg"] = base_nr_per_kg(df_input)

    df_input["features.cogs_gsv"] = cogs_gsv(df_input)

    df_input["features.base_gp"] = base_gp(df_input)

    df_input["features.base_gp_nr"] = base_gp_base_nr(df_input)

    df_input["features.event_gsv_sell_out"] = event_gsv_sell_out(df_input)

    df_input["features.event_var_spend_gsv"] = event_var_spend_gsv(df_input)

    df_input["features.event_gtn"] = event_gtn(df_input)

    df_input["features.event_nr"] = event_nr(df_input)

    df_input["features.event_cogs_to_consumer"] = event_cogs_consumer(df_input)

    df_input["features.event_cogs_for_calc"] = event_cogs_calc(df_input)

    df_input["features.event_gp"] = event_gp(df_input)

    df_input["features.event_gp_nr"] = event_gp_nr(df_input)

    df_input["features.inc_unit"] = inc_unit(df_input)

    df_input["features.inc_kg"] = inc_kg(df_input)

    df_input["features.inc_gsv"] = inc_gsv(df_input)

    df_input["features.inc_terms"] = inc_terms(df_input)

    df_input["features.inc_variable_spend"] = inc_variable_spend(df_input)

    df_input["features.inc_nr"] = inc_nr(df_input)

    df_input["features.inc_gp"] = inc_gp(df_input)

    df_input["features.nr_uplift"] = nr_uplift(df_input)

    df_input["features.addnl_consumer_spend"] = 0

    df_input["features.sell_in_units"] = 0

    df_input["features.base_gtn"] = base_gtn(df_input)

    df_input["features.event_gsv_sell_in"] = event_gsv_sell_in(df_input)
    
    df_input["features.event_total_spend"] = event_total_spend(df_input)

    df_input["features.event_total_spend_gsv"] = event_total_spend_gsv(df_input)

    df_input["features.event_cogs_to_customer"] = event_cogs_to_customer(df_input)

    df_input["features.inc_gtn"] = inc_gtn(df_input)

    df_input["features.inc_spend"] = inc_spend(df_input)

    df_input["features.roi"] = cal_roi(df_input)

    df_input["features.bucket"] = find_bucket(df_input)

    logger.info('Algorithm Event calculation Done...')
    
    return df_input






def monthly_baseline(df,ppg,ret,year,event_start,event_end,baseline_col,incremental_col):
   
    no_of_days = int(len(pd.date_range(pd.to_datetime(year+"-01-01"),pd.to_datetime(year+"-12-31"))))

    df_dates = pd.DataFrame()
    
    df_dates["date"] = pd.date_range(start = pd.to_datetime(year+"-01-01"),end = pd.to_datetime(year+"-12-31"))
    
    df = df.loc[df["ppg"] == ppg]
    df = df.loc[df["retailer"] == ret]
    df = df.loc[df["year"] == int(year)]
    df_final = pd.DataFrame()
      
    df_final = df_dates.merge(df,how='cross') 
    df_final = df_final[(df_final["date"] >= df_final[event_start]) &
                        (df_final["date"] <= df_final[event_end])]
    
    df_final["no_of_days"] = (df_final[event_end] -df_final[event_start]).dt.days

    df_final["no_of_days"] = df_final["no_of_days"]+1

    df_final["baseline"] = df_final[baseline_col] / df_final["no_of_days"]

    df_final["incremental"] = df_final[incremental_col] / df_final["no_of_days"]
    
    df_final = df_final.groupby("date",as_index=False)[["baseline","incremental"]].mean()
    
    df_merged = pd.merge(df_dates, df_final,on = "date", how="left")
    
    ab = df_merged.groupby([df_merged.date.dt.month])["baseline"].transform('mean')

    df_merged["baseline"] = df_merged["baseline"].fillna(ab)
    
    df_merged["month"] = df_merged["date"].dt.strftime("%b")

    df_merged1 = df_merged.groupby("month",as_index = False)["baseline","incremental"].sum()
    
    df_merged1["ppg"] = ppg

    df_merged1["retailer"] = ret

    df_merged1["year"] = year
    
    return df_merged1
    

def get_view_summary_baseline_incremental(df,df_conso,event_start,event_end,baseline_col,incremental_col):
    consolidated_monthly_data  = pd.DataFrame()
    df = df[df[event_end].notna()]
    df["year"] = pd.DatetimeIndex(df[event_end]).year
    df["lookup"] = df["year"].astype(str)+","+ df["retailer"]+","+ df["ppg"]
    dfs = pd.DataFrame()
   
    for i in df['lookup'].unique():
        df1 = df[df['lookup'] == i]

        ppg  = i.split(",")[2]
        ret  = i.split(",")[1]
        year = i.split(",")[0]
        
        monthly_data = monthly_baseline(df1,ppg,ret,year,event_start,event_end,baseline_col,incremental_col)
        consolidated_monthly_data = pd.concat([monthly_data,consolidated_monthly_data])
        dfs = pd.concat([monthly_data , dfs])
    
    df_res = pd.merge(df_conso,dfs,on = ["ppg","retailer","month"],how = "left")

    df_res["predicted_baseline"] = np.where((df_res['baseline'] == 0) | (df_res['baseline'].isna()),
                                      df_res["baseline_old"],df_res["baseline"])
   
    df_res["predicted_incremental"] = np.where((df_res['incremental'] == 0) | (df_res['incremental']).isna(),
                                      df_res["incrementals_old"],df_res["incremental"])
   
    df_res["predicted_total"] = df_res["predicted_baseline"] + df_res["predicted_incremental"]  
    
    return df_res
