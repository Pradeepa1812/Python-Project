import pandas as pd
import json
import numpy as np
import traceback
import sys,os
import logging
from django.shortcuts import render
from rest_framework import viewsets
from rest_framework import filters
from django.http import HttpResponse
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.decorators import api_view, parser_classes
from rest_framework.viewsets import ModelViewSet
from rest_framework.settings import api_settings
from rest_framework_csv.renderers import CSVRenderer
from common.models import Metadata
from scenario.csv_render import HistoricaluploadCsvRenderer,ScenarioCsvRenderer
from common.custom_filters import HistoricalFilter,BaselineYearFilter, ViewSummaryFilter
import django_filters
from common.models import Impact
from scenario import impact , custom_methods
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from rest_framework.parsers import MultiPartParser, FormParser ,FileUploadParser
from rest_framework.views import APIView
from common.paginations import CustomPagination,PaginationHandlerMixin
from django.db.models.functions import ExtractMonth,ExtractYear
from django.http import QueryDict
from rest_pandas import PandasSimpleView
from scenario_log.models import ScenarioLog
from scenario.models import HistoricalSummary,ScenarioSummary,ScenarioPlanner,DefaultValues,DefaultBrandCategory,\
                                                            DebaseBaseline,ModelCoeff,BaselineYear,Competitor
from scenario.serializers import HistoricalSummarySerializers, ScenarioEventsSerializers, ScenarioPlannerCSVSerializers, ScenarioSummarySerializers,ScenarioPlannerSerializers,DefaultValuesSerializers,\
    DefaultBrandCategorySerializers,DebaseBaselineSerializers,ModelCoeffSerializers,BaselineYearSerializers,ScenarioEventsUpdateSerializers,ScenarioInputValiedationSerializers,ScenarioViewSummarySerializer,CompetitorSerializers,BaselineIncremendatelSerializer,ViewSummarySpiltByEventserializer
from scenario_log.serializers import ScenarioLogSerializers

logger = logging.getLogger('django')

class HistoricalViewSet(viewsets.ModelViewSet):
    serializer_class = HistoricalSummarySerializers
    queryset = HistoricalSummary.objects.all().filter(is_disable__exact=0)
    filter_backends = (DjangoFilterBackend, filters.OrderingFilter)
    filter_class = HistoricalFilter
    ordering = ('id')


class ScenarioPlannerViewSet(viewsets.ModelViewSet):
    serializer_class = ScenarioPlannerSerializers
    queryset = ScenarioPlanner.objects.all()
    filter_backends = (DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter)
    pagination_class = None
    filterset_fields = ['retailer', 'category', 'brand', 'ppg', 'event_starts_in_store', 'event_ends_in_store','scenario__scenario_name']
    search_fields = ['ppg', 'retailer', 'brand','category']
    ordering = ('id')

class ScenarioSummaryViewSet(viewsets.ModelViewSet):
    serializer_class = ScenarioSummarySerializers
    queryset = ScenarioSummary.objects.all()
    filter_backends = (DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter)
    filterset_fields = ['scenario_name', ]
    pagination_class = None
    ordering = ('id', 'scenario_name')

class HistoricalCsv(viewsets.ReadOnlyModelViewSet):
    serializer_class = HistoricalSummarySerializers
    queryset = HistoricalSummary.objects.all().filter(is_disable__exact=0)
    filter_backends = (DjangoFilterBackend, filters.OrderingFilter)
    filter_class = HistoricalFilter
    ordering = ('id')
    pagination_class = None
    renderer_classes = [HistoricaluploadCsvRenderer]


class LogReportView(PandasSimpleView):
    def get_data(self,request,*args,**kwargs):
        filters = {"scenario__scenario_name": kwargs.get('scenario__scenario_name')}
        qs = ScenarioPlanner.objects.all().filter(**filters)
        data = custom_methods.log_report_data(qs)
        return data


@api_view(["GET"])
def DefaultValuesViewSet(request):
    ppg = request.GET["ppg"]
    retailer =request.GET["retailer"]
    key = ppg +"_"+retailer+"_Malaysia"
    default_value = DefaultValues.objects.filter(key=str(key))
    default_category_brand = DefaultBrandCategory.objects.filter(key=str(key)).first()
    recommended_impact = Impact.objects.filter(ppg=ppg ,retailer=retailer, impact_type='recommended_impact')

    result = {}
    try:
        result["key"]=default_value[0].key
        if default_category_brand is not None:
            result["brand"] = default_category_brand.brand
            result["category"] = default_category_brand.category
        else:
            result["brand"] = result["category"] = None
            

        for row in default_value:
            result[str(row.feature).replace(" ","_").lower()] = row.default_value

        for row in recommended_impact:
            result[str(row.variable).replace(" ", "_").lower()+'_recommended_impact'] = row.impact

    except:
        result["key"] = key
        result["base_price"] = 8.63
        result["tdp"] = 328.0
        result["list_price"] = 7.21
        result["cogs"] = 2.504357639
        result["off_invoice"] = 0.221
        result["on_invoice"] =0.0
        result["distributor_terms"]=  0.0
        result["grammage"] = 165.0000236
        result["additional_assumed_impact"] = 0.0
        result["baseline_adjustment_factor"] = 0
      
        return Response(data=result)

    return Response(data=result)



class DefaultBrandCategoryViewSet(viewsets.ModelViewSet):
    serializer_class = DefaultBrandCategorySerializers
    queryset = DefaultBrandCategory.objects.all()
    filter_backends = (DjangoFilterBackend, filters.OrderingFilter)
    filterset_fields = ['key','brand','category' ]
    ordering = ('id')
   
class DebaseBaselineViewSet(viewsets.ModelViewSet):
    serializer_class = DebaseBaselineSerializers
    queryset = DebaseBaseline.objects.all()
    filter_backends = (DjangoFilterBackend, filters.OrderingFilter)
    filterset_fields = ['key', ]


class CompetitorViewSet(viewsets.ModelViewSet):
    serializer_class = CompetitorSerializers
    queryset = Competitor.objects.all()
    filter_backends = (DjangoFilterBackend, filters.OrderingFilter)
    pagination_class = None
    filterset_fields = ['ppg','retailer']


@api_view(['GET'])
def baseline_year(request):
    queryset = BaselineYear.objects.all()
    filterset = BaselineYearFilter(request.GET, queryset=queryset)

    if filterset.is_valid():
         queryset = filterset.qs

    if queryset.count()==0:
        queryset = BaselineYear.objects.all()

        request.query_params._mutable = True
        request.query_params['ppg'] = 'All'
        request.query_params._mutable = False

        filterset = BaselineYearFilter(request.query_params, queryset=queryset)

        if filterset.is_valid():
            queryset = filterset.qs

    serializer = BaselineYearSerializers(queryset, many=True)

    try:
        year = serializer.data[0]['baseline_year']
        return Response({"baseline_year": year})
    except:
        return Response(data="no data found",status=status.HTTP_404_NOT_FOUND)


@api_view(['GET'])
def get_first_scenario(request):

    obj = ScenarioPlanner.objects.order_by("scenario_id").exclude(scenario_id=101).values('scenario_id')[0]
    queryset = ScenarioPlanner.objects.all().filter(scenario_id=obj['scenario_id']).values('scenario__scenario_name','brand','ppg')
    return Response(data= queryset[0])

class ModelCoeffViewSet(viewsets.ModelViewSet):
    serializer_class = ModelCoeffSerializers
    queryset = ModelCoeff.objects.all()
    filter_backends = (DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter)
    filterset_fields = ['key', ]
    # ordering = ('id',)


@api_view(['GET', 'POST'])
def algo_calculations(request):
    try:

        if request.method == 'POST':
            global algo_inputs
            logger.info('Input Validation started .....')
            if isinstance(request.data, list):
               algo_inputs = ScenarioInputValiedationSerializers(data=request.data , many = True)
            else:
                algo_inputs = ScenarioInputValiedationSerializers(data=request.data)

            if algo_inputs.is_valid():
                df_input = request.data
                valid_data = {'scenario_events':[request.data]}
                date_validation = custom_methods.date_vallidation(valid_data)
                if date_validation:
                   return Response(data={'Date':'End date should be greater than Start date'}, status=status.HTTP_404_NOT_FOUND)
                coeff_df = pd.DataFrame(list(ModelCoeff.objects.all().values()))
                baseline_df = pd.DataFrame(list(DebaseBaseline.objects.all().values()))
                df_input = pd.DataFrame(pd.json_normalize(df_input))
                logger.info('Algorithm Event Calculation Started..')
                df_final = impact.event_calculation(df_input, coeff_df, baseline_df , True)
                logger.info('Algorithm Event Calculation Done')
                df_final = custom_methods.dates_format_change_algo(df_final)
                result = df_final.to_json(orient='records')
                return Response(data=json.loads(result))

            return Response(data=algo_inputs.errors , status=status.HTTP_404_NOT_FOUND)

    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        response = {'details':'Type of error:{}:Function name:{}:Line number:{}'.format(exc_type, fname, exc_tb.tb_lineno)}
        logger.info(response)
        logger.info(e)
        return Response(data={"Error" : type(e).__name__},status=status.HTTP_404_NOT_FOUND)



@api_view(["POST"])
def scenario_events(request):

    events_data = ScenarioEventsSerializers(data=request.data)

    if events_data.is_valid():

        value,status_code = events_data.save()


        if isinstance(value ,str):
            return Response(data=value, status=status_code)

        else:
            return Response(data=str(value.scenario_name)+" Scenario Created Successfully" ,status=status_code)
    
    return Response(data="Not a Valid data", status=status.HTTP_404_NOT_FOUND)


@api_view(["PUT"])
def scenario_update(request):

    events_data = ScenarioEventsUpdateSerializers(data=request.data)

    if events_data.is_valid():

        value, status_code = events_data.save()

        if isinstance(value, str):
            return Response(data=value, status=status_code)

        else:
            return Response(data=str(value.scenario_name) + " Scenario Updated Successfully",status=status_code)

    return Response(data=events_data.errors ,status=status.HTTP_404_NOT_FOUND)



class upload_data(APIView):

    parser_classes = [MultiPartParser]

    def post(self, request, format=None):

        scenario_file = request.FILES['scenario_file']
        df_input = pd.read_csv(scenario_file)
        coeff_df = pd.DataFrame(list(ModelCoeff.objects.all().values()))
        baseline_df = pd.DataFrame(list(DebaseBaseline.objects.all().values()))
        df_input.columns = custom_methods.data_cleaning(df_input)
        df_input.rename(columns={'event_start_date': 'event_starts_in_store', 'event_end_date': 'event_ends_in_store', 'base_price_%_change': 'base_price_change','distribution':'distributor_terms'}, inplace=True)
        header_value = ['retailer', 'category', 'ppg', 'brand', 'event_starts_in_store', 'event_ends_in_store']
        logger.info('Renaming Column names...')
        for input in df_input:
            if input not in header_value:
                df_input.columns = ["features." + col if col.startswith(input) else col for col in df_input.columns]
        logger.info('Algorithm Event Calculation started...')
        df_final = impact.event_calculation(df_input, coeff_df, baseline_df)
        logger.info('Algorithm Event Calculation Done...')

        df_final.replace([np.inf, -np.inf], np.nan, inplace=True)
        df_final.fillna(0, inplace=True)
        df_final['event_starts_in_store'] = custom_methods.date_format_change(df_final['event_starts_in_store'])
        df_final['event_ends_in_store'] = custom_methods.date_format_change(df_final['event_ends_in_store'])
        data = custom_methods.df_to_formatted_json_data(df_final)
        data= {'scenario_name':request.data["scenario_name"],"scenario_events":data}
        events_data = ScenarioEventsSerializers(data=data)

        if events_data.is_valid():
            value = events_data.save()

            if isinstance(value, str):
                return Response(data=value)
            else:
                return Response(data=str(value.scenario_name) + " Scenario Created Successfully", status=status.HTTP_201_CREATED)
        return Response(data='Not a Valid Data')


@api_view(["POST"])
def promo_mechanics(request):
    promo_value = {}
    promo_value["ppg"]=request.data.get("ppg")
    promo_value["retailer"]=request.data.get("retailer")
    promo_value["features."+request.data.get("promo")]=request.data.get("promo_value")
    promo_df = pd.DataFrame(promo_value,index=[0])
    logger.info('Retrieving Promo impacts...')
    promo_impact_value = custom_methods.promo_impact(promo_df, request.data.get("promo"))
    return Response(data={"features."+request.data.get("promo"):promo_impact_value[0]})


class ScenarioPlannerCsv(viewsets.ReadOnlyModelViewSet):
    serializer_class = ScenarioPlannerCSVSerializers 
    queryset = ScenarioPlanner.objects.all()
    filter_backends = (DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter)
    filterset_fields = ['retailer', 'category', 'brand', 'ppg', 'event_starts_in_store', 'event_ends_in_store','scenario__scenario_name']
    search_fields = ['ppg', 'retailer', 'brand','category']
    ordering = ('id')
    renderer_classes = [ScenarioCsvRenderer]
    pagination_class = None




class ScnarioHistoricalfileUpload(APIView):

    parser_classes = [MultiPartParser]

    def post(self, request, format=None):
        try:
            scenario_file = request.FILES['scenario_file']
        except:
            return Response(data={'CSV File Required...'}, status=status.HTTP_404_NOT_FOUND)

        logger.info('File Uploaded Successfully....')

        result = custom_methods.scenario_file_upload(scenario_file , request.data["scenario_name"])
        return result


class ScenarioViewSummary(APIView,PaginationHandlerMixin):
    pagination_class = CustomPagination
    
    def get(self,request):
        filtered_value = custom_methods.get_filter(request)
        if isinstance(filtered_value, Response):
            return filtered_value
        filtered_value =filtered_value[filtered_value['baseline'].notna()].to_dict("records")
        filtered_value = ScenarioViewSummarySerializer(filtered_value ,many=True)
        # paginated_queryset = self.paginate_queryset(filtered_value.data)
        # filtered_value = {'count':len(filtered_value.data),'result':paginated_queryset}
        return Response(data=filtered_value.data)
        

class ScenarioTargetViewPercentage(APIView, PaginationHandlerMixin):

    def get(self, request):
        filtered_value = custom_methods.get_target_filter(request)
        return Response(data=filtered_value)

class ScenarioViewBaselineIncremendatel(viewsets.ReadOnlyModelViewSet):
    serializer_class = BaselineIncremendatelSerializer
    queryset = ScenarioPlanner.objects.all()
    filter_backends = (DjangoFilterBackend, filters.OrderingFilter)
    filter_class = ViewSummaryFilter
    pagination_class = None
    ordering = ('id')


class ViewSummarySpiltByEvents(viewsets.ReadOnlyModelViewSet):
    serializer_class = ViewSummarySpiltByEventserializer
    queryset = ScenarioPlanner.objects.all()
    filter_backends = (DjangoFilterBackend, filters.OrderingFilter)
    pagination_class = None
    filter_class = ViewSummaryFilter
    ordering = ('serial_no')

@api_view(["GET"])
def DefaultValuesNew(request):
    ppg = request.GET["ppg"]
    retailer =request.GET["retailer"]
    key = ppg +"_"+retailer+"_Malaysia"
    default_value = DefaultValues.objects.filter(key=str(key))
    default_category_brand = DefaultBrandCategory.objects.filter(key=str(key)).first()
    recommended_impact = Impact.objects.filter(ppg=ppg ,retailer=retailer, impact_type='recommended_impact')
    
    result = {}
    try:
        result = custom_methods.get_actual_impact(ppg , retailer )
        result["key"]=default_value[0].key
        if default_category_brand is not None:
            result["brand"] = default_category_brand.brand
            result["category"] = default_category_brand.category
        else:
            result["brand"] = result["category"] = None
            

        for row in default_value:
            result[str(row.feature).replace(" ","_").lower()] = row.default_value

        for row in recommended_impact:
            result[str(row.variable).replace(" ", "_").lower()+'_recommended_impact'] = row.impact if row.impact ==1 else (row.impact/100)+1

    except:
        result = custom_methods.get_actual_impact(ppg , retailer )
        result["key"] = key
        result["base_price"] = 8.63
        result["tdp"] = 328.0
        result["list_price"] = 7.21
        result["cogs"] = 2.504357639
        result["off_invoice"] = 0.221
        result["on_invoice"] =0.0
        result["distributor_terms"]=  0.0
        result["grammage"] = 165.0000236
        result["additional_assumed_impact"] = 0.0
        result["baseline_adjustment_factor"] = 0
      
        return Response(data=result)

    return Response(data=result)

@api_view(["GET"])
def compare_filter_dependends(request):
    results = custom_methods.get_filter_value(request)
    return results

@api_view(['GET'])
def historical_dependent_filters(request):
    results = custom_methods.get_historical_filter_list(request)
    return results
    






























