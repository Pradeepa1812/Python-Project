import decimal
import datetime
from django.db import models
from decimal import Decimal
from rest_framework import serializers
from drf_writable_nested.serializers import WritableNestedModelSerializer
from common.models import Features, Metadata
from scenario import custom_methods
from scenario_log import log_custom_methods
from scenario.models import HistoricalSummary,ScenarioSummary,ScenarioPlanner,DefaultValues,DefaultBrandCategory,\
                                                            DebaseBaseline,ModelCoeff,BaselineYear,Competitor
from scenario_log.models import ScenarioLog

from rest_framework import status



import logging
logger = logging.getLogger('django')

class PercentageField(serializers.Field):
   
    def to_representation(self, value):
        return str(round(value*100 , 2))+"%"

class PercentageWholeField(serializers.Field):
   
    def to_representation(self, value):
        return round(value*100 , 10)

class NullField(serializers.Field):

    def to_representation(self, value):
        return value

class HistoricalFeatureSerializer(serializers.Serializer):
        vars = Metadata.objects.filter(table_name="historical", table_column_name__startswith="features.").values('table_column_name','render_data_type')
        for v in vars:
            feature = v['table_column_name'].replace("features.", "")
            data_type = v['render_data_type']
            if data_type == 'int':
                locals()[feature] = serializers.IntegerField()
            elif data_type == 'whole':
                locals()[feature] = serializers.FloatField()
            elif data_type == 'float':
                locals()[feature] = serializers.DecimalField(max_digits=None, decimal_places=2, read_only=True ,rounding=decimal.ROUND_HALF_EVEN)
            elif data_type == 'percentage':
                locals()[feature] =PercentageField()
            elif data_type == 'percentage_whole':
                locals()[feature] =PercentageWholeField()
            elif data_type == 'string':
                locals()[feature] = serializers.CharField()


class ScenarioFeatureSerializer(serializers.Serializer):
        vars = Metadata.objects.filter(table_name="scenario_planner_all").values('table_column_name','render_data_type')
        for v in vars:
            feature = v['table_column_name']
            data_type = v['render_data_type']
            if data_type == 'int':
                locals()[feature] = serializers.IntegerField()
            elif data_type == 'whole':
                locals()[feature] = serializers.FloatField(required=False)
            elif data_type == 'float':
                locals()[feature] = serializers.DecimalField(max_digits=None, decimal_places=2, read_only=True ,rounding=decimal.ROUND_HALF_EVEN, required=False)
            elif data_type == 'percentage':
                locals()[feature] =PercentageField()
            elif data_type == 'percentage_whole':
                locals()[feature] =PercentageWholeField()
            elif data_type == 'string':
                locals()[feature] = serializers.CharField()

class ScenarioFeatureCSVSerializer(serializers.Serializer):
        vars = Metadata.objects.filter(table_name="scenario_csv", table_column_name__startswith="features.").values('table_column_name','render_data_type')
        for v in vars:
            feature = v['table_column_name'].replace("features.", "")
            data_type = v['render_data_type']
            if data_type == 'int':
                locals()[feature] = serializers.IntegerField(required=False)
            elif data_type == 'whole':
                locals()[feature] = serializers.FloatField(required=False)
            elif data_type == 'float':
                locals()[feature] = serializers.DecimalField(max_digits=None, decimal_places=2, read_only=True ,rounding=decimal.ROUND_HALF_EVEN, required=False)
            elif data_type == 'percentage':
                locals()[feature] =PercentageField(required=False)
            elif data_type == 'percentage_whole':
                locals()[feature] =PercentageWholeField(required=False)
            elif data_type == 'string':
                locals()[feature] = serializers.CharField(required=False)


class AlgoInputValidtaionserializer(serializers.Serializer):
    vars = vars = Metadata.objects.filter(table_name="scenario_event_input").values('table_column_name','render_data_type')
    for v in vars:
        feature = v['table_column_name']
        data_type = v['render_data_type']
        if data_type == 'int':
            locals()[feature] = serializers.IntegerField()
        elif data_type == 'float':
            locals()[feature] = serializers.DecimalField(max_digits=None, decimal_places=None)
        elif data_type == 'float_1':
            locals()[feature] = serializers.DecimalField(max_digits=None, decimal_places=None,default=Decimal(0.00), allow_null=True)
        elif data_type == 'string':
            locals()[feature] = serializers.CharField()
        elif data_type == 'string_1':
            locals()[feature] = serializers.CharField(allow_blank=True,default="")


class ScenarioInputValiedationSerializers(serializers.Serializer):

    retailer = serializers.CharField()
    category = serializers.CharField()
    ppg = serializers.CharField()
    brand = serializers.CharField()
    event_starts_in_store = serializers.DateField(required=False)
    event_ends_in_store = serializers.DateField(required=False)
    features = AlgoInputValidtaionserializer()


class HistoricalSummarySerializers(serializers.ModelSerializer):
    event_starts_in_store= serializers.DateField(format='%d-%b-%Y')
    event_ends_in_store = serializers.DateField(format='%d-%b-%Y')
    features = HistoricalFeatureSerializer()

    class Meta:
        model = HistoricalSummary
        fields = ('__all__')


class ScenarioSummarySerializers(serializers.ModelSerializer):
   
    class Meta:
        model = ScenarioSummary
        fields = ('__all__')


class ScenarioPlannerSerializers(WritableNestedModelSerializer):
    serial_no = serializers.IntegerField()
    scenario = ScenarioSummarySerializers(required=False)
    event_starts_in_store = serializers.DateField(format='%d-%b-%Y')
    event_ends_in_store = serializers.DateField(format='%d-%b-%Y')
    features = ScenarioFeatureSerializer()
    class Meta:
        model = ScenarioPlanner
        fields  = ('__all__')


class ScenarioPlannerCSVSerializers(WritableNestedModelSerializer):
    scenario = ScenarioSummarySerializers(required=False)
    event_starts_in_store = serializers.DateField(format='%d-%b-%Y')
    event_ends_in_store = serializers.DateField(format='%d-%b-%Y')
    features = ScenarioFeatureCSVSerializer()
    class Meta:
        model = ScenarioPlanner
        fields  = ('__all__')



class ScenarioEventCalSerializers(WritableNestedModelSerializer):
    scenario = ScenarioSummarySerializers(required=False)
    event_starts_in_store = serializers.DateField(format='%d-%b-%Y')
    event_ends_in_store = serializers.DateField(format='%d-%b-%Y')

    class Meta:
        model = ScenarioPlanner
        fields  = ('__all__')

class ScenarioViewSummarySerializer(serializers.Serializer):
    retailer = serializers.CharField()
    ppg = serializers.CharField()
    brand = serializers.CharField()
    category = serializers.CharField()
    month = serializers.SerializerMethodField('get_month')
    baseline = serializers.SerializerMethodField('get_baseline')
    incremental = serializers.SerializerMethodField('get_incremental')
    total = serializers.SerializerMethodField('get_total')
    

    def get_month(self , obj):
        return obj['month']+"-"+obj['year']
    
    def get_baseline(self , obj):
        return round(obj["predicted_baseline"],2) 

    def get_incremental(self ,obj):
        return round(obj['predicted_incremental'],2)

    def get_total(self , obj):
        return round(obj["predicted_total"],2)



class BaselineIncremendatelSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    serial_no = serializers.IntegerField()
    event_starts_in_store = serializers.DateField(format='%d-%m-%Y')
    event_ends_in_store = serializers.DateField(format='%d-%m-%Y')
    ppg = serializers.CharField()
    brand = serializers.CharField()
    discount = serializers.SerializerMethodField('get_discount')
    visibity = serializers.SerializerMethodField('get_visibility')
    catalogue = serializers.SerializerMethodField('get_catalogue')
    baseline = serializers.SerializerMethodField('get_baseline')
    incremental = serializers.SerializerMethodField('get_incremental')

    def get_id(self , obj):
        return obj.id
    
    def get_brand(self , obj):
        return obj.brand

    def get_discount(self , obj):
        return str(round(obj.features['discount'] *100))+"%"

    def get_visibility(self ,obj):
        visibity = ''
        if obj.features['visibility'] !='' and obj.features['visibility'] != 'No Visibility':
            visibity = obj.features['visibility']
        if str(obj.features['push_promoter']).upper() != 'NO':
            visibity = visibity+",Push Promoter" if visibity != '' else 'Push Promoter'
        if  str(obj.features['big_bet']).upper() != 'NO':
            visibity = visibity+",Big Bet" if visibity != '' else 'Big Bet'

        return visibity

    def get_catalogue(self , obj):
        catalouge = ''
        if str(obj.features['mailer']).upper()!='NO':
            catalouge = 'Mailer'
        if str(obj.features['newspaper']).upper()!='NO':
            catalouge = catalouge+",Newspaper" if catalouge != '' else "Newspaper"
        if str(obj.features['social_media']).upper()!='NO':
            catalouge = catalouge+",Social Media" if catalouge != '' else "Social Media"
        return catalouge
        
    def get_baseline(self , obj):
        if obj.features["new_baseline"] ==None:
            obj.features["new_baseline"] =0
        return round(obj.features["new_baseline"]/1000 ,1)

    def get_incremental(self ,obj):
        if obj.features["incremental_units"] ==None:
            obj.features["incremental_units"] =0
        return round(obj.features['incremental_units']/1000,1)


class ViewSummarySpiltByEventserializer(serializers.Serializer):
    id = serializers.SerializerMethodField('get_id')
    brand = serializers.SerializerMethodField('get_brand')
    ppg = serializers.SerializerMethodField('get_ppg')
    date = serializers.SerializerMethodField('get_date')
    nr_uplift = serializers.SerializerMethodField('get_nr_uplift')
    roi = serializers.SerializerMethodField('get_roi')
    event_total_spend = serializers.SerializerMethodField('get_total_spend')

    def get_id(self , obj):
        return obj.id
    
    def get_brand(self , obj):
        return obj.brand

    def get_ppg(self , obj):
        return obj.ppg

    def get_date(self ,obj):
        return str(obj.event_starts_in_store)+' to '+str(obj.event_ends_in_store)
    
    def get_nr_uplift(self , obj):
        if obj.features["nr_uplift"] ==None:
            obj.features["nr_uplift"]=0
        return round(obj.features["nr_uplift"] * 100)

    def get_roi(self , obj):
        if obj.features["roi"] ==None:
            obj.features["roi"]=0
        return round(obj.features["roi"] * 100)
    
    def get_total_spend(self ,obj):
        if obj.features["event_total_spend"] ==None:
            obj.features["event_total_spend"]=0
        return round(obj.features['event_total_spend']/1000,2)


class DefaultValuesSerializers(serializers.ModelSerializer):
    class Meta:
        model = DefaultValues
        fields = ('__all__')


class DefaultBrandCategorySerializers(serializers.ModelSerializer):
    class Meta:
        model = DefaultBrandCategory
        fields = ('__all__')


class DebaseBaselineSerializers(serializers.ModelSerializer):
    class Meta:
        model = DebaseBaseline
        fields = ('__all__')


class ModelCoeffSerializers(serializers.ModelSerializer):
    class Meta:
        model = ModelCoeff
        fields = ('__all__')

class BaselineYearSerializers(serializers.ModelSerializer):
    class Meta:
        model = BaselineYear
        fields = ('__all__')

class CompetitorSerializers(serializers.ModelSerializer):
    class Meta:
        model = Competitor
        fields = ('__all__')


class UploadScenarioEventsSerializers(serializers.Serializer):
    scenario_events = ScenarioEventCalSerializers(many=True)

    scenario_name = serializers.CharField()

    def create(self, validated_data):

            logger.info('Entered into validation ...')

            event_name = validated_data["scenario_name"]
            events = ScenarioSummary.objects.filter(scenario_name=event_name)

            logger.info('Checking Scenario Name Existance.....')

            if len(events)>0 :

                return event_name+" Scenario already exist " ,status.HTTP_409_CONFLICT

            logger.info('Uploaded Data Started saving in Database.....')

            scenario_name = ScenarioSummary.objects.create(scenario_name=event_name)

            scenario_events_list = []

            serial_count = 1

            for event in validated_data["scenario_events"]:
                
                scenarioplanner = ScenarioPlanner(scenario=scenario_name,retailer=event["retailer"],category=event["category"],brand=event["brand"],ppg=event["ppg"],event_starts_in_store=event["event_starts_in_store"],event_ends_in_store=event["event_ends_in_store"],market=event["market"],features=event["features"] ,serial_no=serial_count)

                scenario_events_list.append(scenarioplanner)

                serial_count+=1

            ScenarioPlanner.objects.bulk_create(scenario_events_list)

            return scenario_name ,status.HTTP_201_CREATED


class ScenarioEventsSerializers(serializers.Serializer):
    scenario_events = ScenarioEventCalSerializers(many=True)

    scenario_name = serializers.CharField()

    def create(self, validated_data):

            logger.info('Entered into validation ...')

            validators = custom_methods.unique_together_validators(validated_data)

            if validators == "Yes":
                return "Multiple Retailers Not Allowed",status.HTTP_404_NOT_FOUND

            if validators ==True:
                return "PPG,Brand,StartDate,EndDate Unique Together", status.HTTP_404_NOT_FOUND

            logger.info('Name validation started.....')

            name_validation = custom_methods.event_name_vallidation(validated_data)

            if name_validation != True:
                return "Invalid Name Format", status.HTTP_404_NOT_FOUND

            logger.info('Name validation Done.....')
            logger.info('Date Validation Started....')

            date_validation = custom_methods.date_vallidation(validated_data)

            if date_validation == True:
                return "End date should be greater than Start date ", status.HTTP_404_NOT_FOUND

            logger.info('Date validation Done.....')


            event_name = validated_data["scenario_name"]
            events = ScenarioSummary.objects.filter(scenario_name=event_name)

            logger.info('Checking Scenario Name Existance.....')

            if len(events)>0 :

                return event_name+" Scenario already exist " ,status.HTTP_409_CONFLICT

            logger.info('Uploaded Data Started saving in Database.....')

            print(validated_data["scenario_events"])


            scenario_name = ScenarioSummary.objects.create(scenario_name=event_name)

            scenario_events_list = []

            serial_count = 1

            for event in validated_data["scenario_events"]:
                
                scenarioplanner = ScenarioPlanner(scenario=scenario_name,retailer=event["retailer"],category=event["category"],brand=event["brand"],ppg=event["ppg"],event_starts_in_store=event["event_starts_in_store"],event_ends_in_store=event["event_ends_in_store"],market=event["market"],features=event["features"] , serial_no=serial_count)

                scenario_events_list.append(scenarioplanner)

                serial_count+=1

            ScenarioPlanner.objects.bulk_create(scenario_events_list)

            new_entry = log_custom_methods.old_new_difference(validated_data["scenario_events"],scenario_name)

            print(new_entry)

            return scenario_name ,status.HTTP_201_CREATED


class ScenarioEventsUpdateSerializers(serializers.Serializer):

    scenario_events = ScenarioEventCalSerializers(many=True)

    scenario_name = serializers.CharField()

    def create(self, validated_data):
        print(validated_data)

        validators = custom_methods.unique_together_validators(validated_data)

        if validators == True:
            return "PPG,Brand,StartDate,EndDate Unique Together", status.HTTP_404_NOT_FOUND

        if validators == "Yes":
            return "Multiple Retailers Not Allowed", status.HTTP_404_NOT_FOUND

        event_name = validated_data["scenario_name"]
        events_name = ScenarioSummary.objects.get(scenario_name=event_name)

        if events_name != None:

            logger.info('Updating Data into the Database.....')
            events = ScenarioPlanner.objects.all().filter(scenario=events_name)
            events.delete()
            scenario_events_list = []

            serial_count = 1

            for event in validated_data["scenario_events"]:
                
                scenarioplanner = ScenarioPlanner(scenario=events_name, retailer=event["retailer"],category=event["category"], brand=event["brand"], ppg=event["ppg"], event_starts_in_store=event["event_starts_in_store"], event_ends_in_store=event["event_ends_in_store"],market=event["market"], features=event["features"] ,serial_no=serial_count)
                
                scenario_events_list.append(scenarioplanner)
                
                serial_count+=1
            
            ScenarioPlanner.objects.bulk_create(scenario_events_list)

        return events_name,status.HTTP_201_CREATED


