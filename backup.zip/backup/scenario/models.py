from django.db import models


class BaseInfo(models.Model):
    retailer = models.CharField(max_length=50)
    category = models.CharField(max_length=50)
    brand = models.CharField(max_length=50)
    ppg = models.CharField(max_length=255)
    event_starts_in_store = models.DateField()
    event_ends_in_store = models.DateField()
    market = models.ForeignKey('common.Market', on_delete = models.CASCADE)
    features = models.JSONField()
    created_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        abstract = True


class HistoricalSummary(BaseInfo):
    is_disable = models.BooleanField(default=False)
    class Meta:
        db_table = "tpas_historical_data"


class ScenarioSummary(models.Model):
    scenario_name = models.CharField(max_length=50 ,unique=True)
    market = models.ForeignKey('common.Market', on_delete=models.CASCADE,default=1)
    class Meta:
        db_table = "tpas_scenarios"


class ScenarioPlanner(BaseInfo):
    serial_no = models.IntegerField(default=0)
    scenario = models.ForeignKey(ScenarioSummary, on_delete=models.CASCADE)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = "tpas_scenario_events"


class DefaultValues(models.Model):
    key = models.CharField(max_length=255)
    market = models.ForeignKey('common.Market', on_delete=models.CASCADE)
    feature = models.CharField(max_length=255)
    default_value = models.FloatField(default=0)

    class Meta:
        db_table = "tpas_default_value"

class DefaultBrandCategory(models.Model):
    key = models.CharField(max_length=50)
    market = models.ForeignKey('common.Market', on_delete=models.CASCADE)
    brand = models.CharField(max_length=50)
    category = models.CharField(max_length=50)

    class Meta:
        db_table = "tpas_default_brand_category"

class DebaseBaseline(models.Model):
    key = models.CharField(max_length=255)
    date = models.DateField()
    holiday_impact = models.FloatField(default=0)
    market = models.ForeignKey('common.Market', on_delete=models.CASCADE)
    debase_impact = models.FloatField(default=0)
    total_baseline_contribution = models.FloatField(default=0)
    correct_debased_baseline = models.FloatField(default=0)

    class Meta:
        db_table = "tpas_debase_baseline"


class ModelCoeff(models.Model):
    key = models.CharField(max_length=255)
    market = models.ForeignKey('common.Market', on_delete=models.CASCADE)
    feature = models.CharField(max_length=255)
    default_value = models.FloatField(default=0)

    class Meta:
        db_table = "tpas_model_coeff"

class BaselineYear(models.Model):
    retailer =models.CharField(max_length=50)
    ppg =models.CharField(max_length=50)
    baseline_year =models.CharField(max_length=10)

    class Meta:
        db_table = "tpas_baseline_year"

class Competitor(models.Model):
    retailer = models.CharField(max_length=50)
    ppg = models.CharField(max_length=255)
    competitor_1 = models.CharField(max_length=255)
    competitor_2 = models.CharField(max_length=255)
    class Meta:
        db_table = "tpas_competitor"


class Baselines(models.Model):
    retailer = models.CharField(max_length=50)
    category = models.CharField(max_length=50)
    brand = models.CharField(max_length=50)
    ppg = models.CharField(max_length=255)
    month = models.CharField(max_length=50)
    baseline_old = models.FloatField()
    incrementals_old = models.FloatField()

    class Meta:
        db_table = "tpas_baselines"


