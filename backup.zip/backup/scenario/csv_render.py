from rest_framework.settings import api_settings
from rest_framework_csv.renderers import CSVRenderer
from common.models import Metadata
from scenario import custom_methods

class HistoricaluploadCsvRenderer(CSVRenderer):

    table_name = ["historical"]

    head_values = custom_methods.headerBuild(table_name)

    header = list(head_values.keys())

    labels = head_values


class ImpactCsvRenderer(CSVRenderer):

    table_name = ["impact",]

    head_values = custom_methods.headerBuild(table_name)

    header = list(head_values.keys())

    labels = head_values


class ScenarioCsvRenderer(CSVRenderer):
    
    table_name = ["scenario_csv",]

    head_values = custom_methods.headerBuild(table_name)

    header = list(head_values.keys())

    labels = head_values
