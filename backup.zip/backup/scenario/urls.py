from django.urls import path, include, re_path
from rest_framework.routers import DefaultRouter
from scenario import views

router = DefaultRouter()
router.register(r'historical', views.HistoricalViewSet)
router.register(r'scenario-planner', views.ScenarioPlannerViewSet)
router.register(r'scenario-summary', views.ScenarioSummaryViewSet)
router.register(r'historical-csv', views.HistoricalCsv)
router.register(r'default-brand-category', views.DefaultBrandCategoryViewSet)
router.register(r'debase-baseline', views.DebaseBaselineViewSet)
router.register(r'model-coeff', views.ModelCoeffViewSet)
router.register(r'scenario-planner-csv', views.ScenarioPlannerCsv)
router.register(r'competitor', views.CompetitorViewSet)
router.register(r'view-summary-chart-a', views.ScenarioViewBaselineIncremendatel)
router.register(r'view-summary-chart-b', views.ViewSummarySpiltByEvents)

urlpatterns = [
    path('api/', include(router.urls)),
    path(r'api/default-values', views.DefaultValuesViewSet),
    path(r'api/algo-calculations',views.algo_calculations),
    path(r'api/scenario-events', views.scenario_events),
    path(r'api/scenario-update',views.scenario_update),
    path(r'api/scenario-file-upload', views.upload_data.as_view()),
    path(r'api/promo-impact' , views.promo_mechanics),
    path(r'api/scenario-new-file-upload', views.ScnarioHistoricalfileUpload.as_view()),
    path(r'api/baseline-year', views.baseline_year),
    path(r'api/view-summary-table', views.ScenarioViewSummary.as_view()),
    path(r'api/view-target-summary-table', views.ScenarioTargetViewPercentage.as_view()),
    path(r'api/default-value-new' , views.DefaultValuesNew),
    path(r'api/scenario-compare-filter', views.compare_filter_dependends),
    path(r'api/historical-filters-list' ,views.historical_dependent_filters),
    path(r'api/first-scenario', views.get_first_scenario),
    path(r'api/log-report/<str:scenario__scenario_name>', views.LogReportView.as_view()),

]




