from django.db.models import fields
from django_filters import filters, FilterSet
from scenario.models import HistoricalSummary,BaselineYear, ScenarioPlanner
from common.models import Impact, Market, Metadata,Target


class HistoricalFilter(FilterSet):

    for meta_data in Metadata.objects.filter(market=1):
        locals()[str(meta_data.table_column_name).replace('.', '__')] = filters.CharFilter(
            field_name=str(meta_data.table_column_name).replace('.', '__'), lookup_expr='exact')

    class Meta:
        model = HistoricalSummary
        fields = {
            'retailer': ['exact'],
            'category': ['exact'],
            'brand': ['exact'],
            'ppg': ['exact'],
            'event_ends_in_store': ['year'],
        }

class TargetFilter(FilterSet):

    class Meta:
        model = Target
        fields = {
            'retailer': ['exact'],
            'ppg': ['exact'],
            'input_target_units': ['exact'],
            'actual_units_sold': ['exact'],
            'target_completion': ['exact'],
            'year': ['year'],
        }


class ImpactFilter(FilterSet):
  #  scenario__scenario__scenario_name = filters.CharFilter(field_name='scenario__scenario__scenario_name', lookup_expr='icontains')
    scenario__retailer = filters.CharFilter(field_name='scenario__retailer', lookup_expr='exact')
    scenario__ppg = filters.CharFilter(field_name='scenario__ppg', lookup_expr='icontains')
    
    class Meta:
        model = Impact
        fields = {
            'variable': ['icontains'],
            'impact' : ['icontains'],
            'market' : ['exact'],
        }

class BaselineYearFilter(FilterSet):
    class Meta:
        model = BaselineYear
        fields = ['retailer','ppg']


class CharInFilter(filters.BaseInFilter, filters.CharFilter):
    pass
    
class ViewSummaryFilter(FilterSet):
    brand = CharInFilter(field_name='brand', lookup_expr='in')
    retailer = CharInFilter(field_name='brand', lookup_expr='in')
    ppg = CharInFilter(field_name='ppg', lookup_expr='in')
    year = filters.CharFilter(field_name='event_ends_in_store__year')

    class Meta:
        model = ScenarioPlanner
        fields = ['brand', 'scenario__scenario_name', 'ppg', 'year', 'retailer']
