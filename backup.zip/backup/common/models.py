from django.db import models
from django_mysql.models import EnumField

class Market(models.Model):
    market_name = models.CharField(max_length=100)

    class Meta:
        db_table = "tpas_market"


class Glossary(models.Model):
    column_name = models.CharField(max_length=50)
    cell_type = models.CharField(max_length=50)
    entries = models.CharField(max_length=50)
    data_type = models.CharField(max_length=50)
    market = models.ForeignKey(Market, on_delete=models.CASCADE)

    class Meta:
        db_table = "tpas_glossary"


class Target(models.Model):
    retailer = models.CharField(max_length=50)
    ppg = models.CharField(max_length=255)
    input_target_units = models.IntegerField(default=0)
    actual_units_sold = models.IntegerField(default=0)
    target_completion = models.IntegerField(default=0)
    year = models.DateField()
    market = models.ForeignKey(Market, on_delete=models.CASCADE)

    class Meta:
        db_table = "tpas_target"


class Impact(models.Model):
    ppg = models.CharField(max_length=150 ,default=None)
    retailer = models.CharField(max_length=150 ,default=None)
    variable = models.CharField(max_length=50 ,default=None)
    impact_type = models.CharField(max_length=50 , default=None)
    impact = models.IntegerField()
    market = models.ForeignKey(Market, on_delete=models.CASCADE)

    class Meta:
        db_table = "tpas_impact"

class Metadata(models.Model):
    table_name = models.CharField(max_length=50)
    table_column_name = models.CharField(max_length=50)
    ui_name = models.CharField(max_length=50)
    ui_ordering = models.DecimalField(max_digits=2, decimal_places=2, default=0.0)
    ui_show = models.BooleanField(default=False)
    market = models.ForeignKey(Market, on_delete=models.CASCADE)
    ui_align = models.CharField(max_length=50 , default='left')
    data_type = EnumField(choices=['int', 'float', 'string', 'date', 'percentage'],default="string")
    width = models.IntegerField(default=150)
    is_default_column = models.BooleanField(default=False)
    render_data_type = EnumField(choices=['int', 'float', 'string', 'date', 'percentage', 'percentage_whole', 'whole' , 'string_1' ,'float_1'],default="string")
    
    class Meta:
        db_table = "tpas_metadata"



class Features(models.Model):
    feature_name = models.CharField(max_length=50)
    feature_data_type = models.CharField(max_length=50)
    feature_formula = models.TextField(null=True,blank=True)
    table = models.CharField(max_length=50, default="historical_summary")
    market = models.ForeignKey(Market, on_delete=models.CASCADE)
    class Meta:
        db_table = "tpas_features"


class Retailer(models.Model):
    id = models.IntegerField(primary_key=True)
    retailer = models.CharField(max_length=50)
    market = models.ForeignKey(Market, on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = "tpas_retailer"


class Category(models.Model):
    id = models.IntegerField(primary_key=True)
    category = models.CharField(max_length=50)
    market = models.ForeignKey(Market, on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = "tpas_category"


class Brand(models.Model):
    id = models.IntegerField(primary_key=True)
    brand = models.CharField(max_length=50)
    market = models.ForeignKey(Market, on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = "tpas_brand"


class Ppg(models.Model):
    id = models.IntegerField(primary_key=True)
    ppg = models.CharField(max_length=255)
    market = models.ForeignKey(Market, on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = "tpas_ppg"

class PpgRetailer(models.Model):
    id = models.IntegerField(primary_key=True)
    ppg = models.CharField(max_length=255)
    retailer = models.CharField(max_length=50)
    market = models.ForeignKey(Market, on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = "tpas_ppg_retailer"


class Year(models.Model):
    id = models.IntegerField(primary_key=True)
    year = models.CharField(max_length=255)
    market = models.ForeignKey(Market, on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = "tpas_year"

class Visibility(models.Model):
    id = models.IntegerField(primary_key=True)
    visibility = models.CharField(max_length=255)
    market = models.ForeignKey(Market, on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = "tpas_visibility"


class CompareBaseYear(models.Model):

    year = models.DateField()

    class Meta:
        db_table = "tpas_compare_base_year"
