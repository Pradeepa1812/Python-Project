from django.shortcuts import render
from rest_framework import viewsets
from rest_framework import filters
from common.custom_filters import ImpactFilter, TargetFilter
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework_csv.renderers import CSVRenderer
from scenario.csv_render import ImpactCsvRenderer
from rest_framework_bulk import (ListBulkCreateUpdateDestroyAPIView,BulkModelViewSet)

from common.serializers import GlossarySerializers,TargetSerializers,ImpactSerializers,MarketSerializers, FeaturesSerializers,RetailerSerializers,CategorySerializers,\
                        BrandSerializers,PpgSerializers, YearSerializers ,MetadataBulkSerializers,VisibilitySerializers,PpgRetailerSerializers

from common.models import Glossary,Target,Impact,Market,Metadata,Features,Retailer,Category,Brand,Ppg,Year,Visibility,PpgRetailer


class GlossaryViewSet(viewsets.ModelViewSet):
    serializer_class = GlossarySerializers
    queryset = Glossary.objects.all()
    filter_backends = (DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter)
    filterset_fields = ['column_name',]
    search_fields = ['column_name', 'entries']
    ordering = ('column_name', 'id')


class TargetViewSet(viewsets.ModelViewSet):
    serializer_class = TargetSerializers
    queryset = Target.objects.all()
    filter_backends = (DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter)
    filter_class = TargetFilter
    ordering = ('id' , 'target_completion')


class ImpactViewSet(viewsets.ModelViewSet):
    serializer_class = ImpactSerializers
    queryset = Impact.objects.all()
    filter_backends = (DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter)
    filterset_fields = ['retailer', 'ppg']
    ordering = ('id' , 'impact')

class ImpactCsv(viewsets.ReadOnlyModelViewSet):
    serializer_class = ImpactSerializers
    queryset = Impact.objects.all()
    filter_backends = (DjangoFilterBackend, filters.OrderingFilter)
    filterset_fields = ['retailer', 'ppg']
    pagination_class = None
    renderer_classes = [ImpactCsvRenderer]


class MarketViewSet(viewsets.ModelViewSet):
    serializer_class = MarketSerializers
    queryset = Market.objects.all()
    filter_backends = (DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter)
    filterset_fields = ['market_name',]
    ordering = ('id')

class MetadataBulkViewSet(BulkModelViewSet):
    queryset = Metadata.objects.all()
    serializer_class = MetadataBulkSerializers
    pagination_class = None
    filter_backends = (DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter)
    filterset_fields = ['ui_name','ui_show','table_column_name', 'table_name', 'is_default_column']
    search_fields = ['ui_ordering', 'table_name']
    ordering = ('id')

class FeaturesViewSet(viewsets.ModelViewSet):
    serializer_class = FeaturesSerializers
    queryset = Features.objects.all()
    filter_backends = (DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter)
    ordering = ('id')
    

class RetailerViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = RetailerSerializers
    queryset = Retailer.objects.all()
    filter_backends = (DjangoFilterBackend, filters.OrderingFilter)
    filterset_fields = ['market']
    ordering = ('retailer')
    pagination_class = None

class CategoryViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = CategorySerializers
    queryset = Category.objects.all()
    filter_backends = (DjangoFilterBackend, filters.OrderingFilter)
    filterset_fields = ['market']
    ordering = ('id','category')
    pagination_class = None


class BrandViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = BrandSerializers
    queryset = Brand.objects.all()
    filter_backends = (DjangoFilterBackend, filters.OrderingFilter)
    filterset_fields = ['market']
    ordering = ('brand')
    pagination_class = None


class PpgViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = PpgSerializers
    queryset = Ppg.objects.all()
    filter_backends = (DjangoFilterBackend, filters.OrderingFilter)
    filterset_fields = ['market']
    ordering = ('ppg')
    pagination_class = None

class PpgRetailerViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = PpgRetailerSerializers
    queryset = PpgRetailer.objects.all()
    filter_backends = (DjangoFilterBackend, filters.OrderingFilter)
    filterset_fields = ['market','retailer']
    ordering = ('retailer')
    pagination_class = None

class YearViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = YearSerializers
    queryset = Year.objects.all()
    filter_backends = (DjangoFilterBackend, filters.OrderingFilter)
    filterset_fields = ['market']
    ordering = ('year')
    pagination_class = None

class VisibilityViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = VisibilitySerializers
    queryset = Visibility.objects.all()
    filter_backends = (DjangoFilterBackend, filters.OrderingFilter)
    filterset_fields = ['market']
    ordering = ('visibility')
    pagination_class = None