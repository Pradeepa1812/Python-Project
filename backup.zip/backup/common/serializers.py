from rest_framework import serializers
from common.models import Glossary,Target,Impact,Market,Metadata,Features,Retailer,Category,Brand,Ppg,Year,Visibility,PpgRetailer
from rest_framework_bulk import (BulkListSerializer,BulkSerializerMixin,ListBulkCreateUpdateDestroyAPIView,)
from scenario.serializers import ScenarioPlannerSerializers

class GlossarySerializers(serializers.ModelSerializer):
    class Meta:
        model = Glossary
        fields = ('__all__')
        
class TargetSerializers(serializers.ModelSerializer):
    class Meta:
        model = Target
        fields  = ('__all__')

class ImpactSerializers(serializers.ModelSerializer):
    impact = serializers.SerializerMethodField('get_type_value')
       
    class Meta:
        model = Impact
        fields  = ('__all__')

    def get_type_value(self , obj):
        return str(obj.impact_type).replace("_", " ").title()+": "+str(obj.impact)+"%"


class MarketSerializers(serializers.ModelSerializer):
    class Meta:
        model = Market
        fields  = ('__all__')

class MetadataBulkSerializers(BulkSerializerMixin, serializers.ModelSerializer):
    class Meta(object):
        model = Metadata
        fields = '__all__' 
        list_serializer_class = BulkListSerializer

class FeaturesSerializers(serializers.ModelSerializer):
    class Meta:
        model = Features
        fields  = ('__all__')

class RetailerSerializers(serializers.ModelSerializer):
    class Meta:
        model = Retailer
        fields = ('__all__')

class CategorySerializers(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ('__all__')

class BrandSerializers(serializers.ModelSerializer):
    class Meta:
        model = Brand
        fields = ('__all__')

class PpgSerializers(serializers.ModelSerializer):
    class Meta:
        model = Ppg
        fields = ('__all__')

class PpgRetailerSerializers(serializers.ModelSerializer):
    class Meta:
        model = PpgRetailer
        fields = ('__all__')

class YearSerializers(serializers.ModelSerializer):
    class Meta:
        model = Year
        fields = ('__all__')

class VisibilitySerializers(serializers.ModelSerializer):
    class Meta:
        model = Visibility
        fields = ('__all__')