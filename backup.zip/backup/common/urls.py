from django.urls import path, include, re_path
from rest_framework.routers import DefaultRouter
from rest_framework_bulk.routes import BulkRouter


from common import views

router = DefaultRouter()
router.register(r'glossary', views.GlossaryViewSet)
router.register(r'target',views.TargetViewSet)
router.register(r'impact',views.ImpactViewSet)
router.register(r'impact-csv', views.ImpactCsv)
router.register(r'market',views.MarketViewSet)
router.register(r'features', views.FeaturesViewSet)
router.register(r'retailer', views.RetailerViewSet)
router.register(r'category', views.CategoryViewSet)
router.register(r'brand', views.BrandViewSet)
router.register(r'ppg', views.PpgViewSet)
router.register(r'year', views.YearViewSet)
router.register(r'visibility', views.VisibilityViewSet)
router.register(r'ppg-retailer', views.PpgRetailerViewSet)
router_bulk = BulkRouter()
router_bulk.register(r'metadata',views.MetadataBulkViewSet)

urlpatterns = [
    path('api/', include(router.urls)),
    path('api/', include(router_bulk.urls)),

]

